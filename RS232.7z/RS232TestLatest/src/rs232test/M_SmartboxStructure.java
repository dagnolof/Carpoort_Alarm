/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs232test;

/**
 *
 * @author fdag0
 */
public class M_SmartboxStructure {
    /* Datasefinitions in the DataStructure Class */
    private int D_Smartbox_id;
    private String D_Gsm_Nbr;
    private int D_Nbr_Of_Sondes;
    //We are n ot going to store the sonde data in a memory structure. If the program restarts
    //we lose the non saved data. Therefore we zill store the sonde data in a file on the harddrive.
    //private M_SondeStructure[] D_SondeData; 

    
    public M_SmartboxStructure(String d_smartbox_id, String d_gsm_nr) {
        this.D_Smartbox_id = Integer.parseInt(d_smartbox_id);
        this.D_Gsm_Nbr = d_gsm_nr;
    }
    
    
    public void Set_Nbr_Of_Sondes(String d_Nbr_Of_Sondes) {
        this.D_Nbr_Of_Sondes = Integer.parseInt(d_Nbr_Of_Sondes);
    }
 
    
    public Integer Get_Nbr_Of_Sondes() {
        return this.D_Nbr_Of_Sondes;
    }
    
    
    public String  Get_Gsm_Nbr() {
        return this.D_Gsm_Nbr;
    }
}
