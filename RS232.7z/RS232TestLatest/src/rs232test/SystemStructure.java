package rs232test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author fdag0
 */
public class SystemStructure {
    private boolean L_ModemConnectedFlag = false;
    private boolean L_DatabaseParcedFlag = false;
    
    // 2-Nov-2019 V06
    // Add Modemtype 
    private String L_Modem_Type;

    public SystemStructure() {

    }
    
    /**
     * Set the L_ModemConnectedFlag in the RxTxRs232Structure.
     * This means that the Gsm Modem is connected to a provider.
     * @param ModemConnectedFlag
     */
    public synchronized void SetModemConnectedFlag (boolean modemConnectedFlag){
        this.L_ModemConnectedFlag = modemConnectedFlag;
    }
    
    
     /**
     * Set the L_DatabaseParcedFlag
     * This means that the application parced the Mysql database.
     * The application can start the Sms handler
     * @param DatabaseParcedFlag
     */
    public synchronized void SetDatabaseParcedFlag (boolean databaseParcedFlag){
        this.L_DatabaseParcedFlag = databaseParcedFlag;
    }
    
    
    /**
     * Return the L_ModemConnectedFlag to the caller.
     * If this flag is set it means that the modem is connected to a provider
     * @return L_ModemConnectedFlag
     */
    public synchronized boolean GetModemConnectedFlag() {
        return this.L_ModemConnectedFlag;
    } 
    
    
    /**
     * Get the L_DatabaseParcedFlag
     * This means that the application parced the Mysql database.
     * The application can start the Sms handler
     * @param DatabaseParcedFlag
     */
    public synchronized boolean GetDatabaseParcedFlag(){
        return this.L_DatabaseParcedFlag;
    }
    
    
    /**
     * Set Modem Type
     * Met AT-CGMM commando lezen we het verbonden modem type uit.
     * We schrijven het hier weg
     * @param ModemType
     */
    public synchronized void SetModemType(String ModemType){
        this.L_Modem_Type = ModemType;
    }
    
    
    /**
     * Get Modem Type
     * Met AT-CGMM commando lezen we het verbonden modem type uit.
     * Hier lezen we het gestockeerde Modem-Type uit.
     * @param L_Modem_Type
     */
    public synchronized String GetModemType(String ModemType){
        return this.L_Modem_Type;
    }
}
