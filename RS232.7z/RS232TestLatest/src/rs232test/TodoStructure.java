/* The TodoSctructure will contain one entry to keep track of the actual todo task.
 * The L_Available and L_Busy flags will indicate the state of the entry.
 */
package rs232test;

/**
 *
 * @author fdag0
 */
public class TodoStructure {

    private String L_d_id;
    private String L_d_user_id;
    private String L_d_user_name;
    private String L_d_smartbox_id;
    private String L_d_gsm_nr;
    
    // V04 16-Oct-2019
    // Add variables for Gsm_Actions application
    private String L_d_unit_id;
    private String L_d_sensor_id;
    private String L_d_alarm_text;
    
    // V04 13-Oct-2019
    // Add String L_Application to differntiate bewteen Tank-Monitor or Gsm_Sensor Action
    private String L_application;
    private Integer L_d_nbr_of_sondes;
    private Boolean L_d_immediate_action_Flag;
    private java.sql.Time L_d_time;
    private boolean L_Entry_Available_Flag = false;
    private boolean L_Busy_Flag = false;
    
    
    //Class constructor
    public TodoStructure(){
        
    }
    
    
    
    public void CreateTodoEntry_tankmonitor(String L_Application, String d_id, String d_user_id, String d_user_name, String d_smartbox_id, String d_gsm_nr, Integer d_nbr_of_sondes, Boolean d_immediate_action, java.sql.Time d_time, Boolean Entry_Available_Flag) {
      this.L_d_id = d_id;
      this.L_d_user_id = d_user_id;
      this.L_d_user_name = d_user_name;
      this.L_d_smartbox_id = d_smartbox_id;
      this.L_d_gsm_nr = d_gsm_nr;
      this.L_d_nbr_of_sondes = d_nbr_of_sondes;
      this.L_Entry_Available_Flag = Entry_Available_Flag;
      this.L_d_time = d_time;
      this.L_d_immediate_action_Flag = d_immediate_action;
      this.L_application = L_Application;
    }

    
    
    public void CreateTodoEntry_gsm_actions(String L_Application, String d_id, String d_unit_id, String d_sensor_id, String d_gsm_nr, String d_alarm_text, Boolean Entry_Available_Flag) {
      this.L_d_id = d_id;
      this.L_d_unit_id = d_unit_id;
      this.L_d_sensor_id = d_sensor_id;
      this.L_d_gsm_nr = d_gsm_nr;
      this.L_d_alarm_text = d_alarm_text;
      this.L_Entry_Available_Flag = Entry_Available_Flag;
      this.L_application = L_Application;
    }
    
    /**
     * Change the L_Busy_Flag to indicate if there is activity on this entry
     * False: No actions on this entry in progress
     * True : Actions on this entry in progress
     *
     * @param Busy_Flag 
     */
    public synchronized void ChangeBusyFlag(boolean Busy_Flag) {
        this.L_Busy_Flag = Busy_Flag;
    }
    
    
    /**
     * Change the L_Entry_Available_Flag to indicate if the entry is available for processing
     * False: Entry is not available for processing
     * True : Entry is available for processing
     *
     * @param Entry_Available_Flag 
     */
    public synchronized void ChangeEntryAvailableFlag(boolean Entry_Available_Flag) {
        this.L_Entry_Available_Flag = Entry_Available_Flag;
    }
    
    
    /**
     * Get L_application
     * L_application string differentiates between Tank-monitor and Gsm Action application
     *
     * @param L_application
     */
    public synchronized String GetApplication() {
        return this.L_application;
    }
    
    
    /**
     * Get d_id
     *
     * @param L_d_id 
     */
    public synchronized String GetId() {
        return this.L_d_id;
    }
    
    
    /**
     * Get d_user_id
     *
     * @param L_d_user_id 
     */
    public synchronized String GetUserId() {
        return this.L_d_user_id;
    }
    
   
    
    /**
     * Get d_user_name
     *
     * @param L_d_user_name 
     */
    public synchronized String GetUserName() {
        return this.L_d_user_name;
    }
    
    
    /**
     * Get d_time
     *
     * @param L_time 
     */
    public synchronized java.sql.Time GetTime() {
        return this.L_d_time;
    }
    
    
    
    /**
     * Get d_nbr_of_sondes
     *
     * @param L_d_nbr_of_sondes
     */
    public synchronized Integer GetNbrOfSondes() {
        return this.L_d_nbr_of_sondes;
    }
    
    
    /**
     * Get d_gsm_nr
     *
     * @param L_d_gsm_nr 
     */
    public synchronized String GetGsmNr() {
        return this.L_d_gsm_nr;
    }
    
    
    /**
     * Get d_alarm_text
     *
     * @param L_d_alarm_text
     */
    public synchronized String GetAlarmText() {
        return this.L_d_alarm_text;
    }
    
    
    
    /**
     * Get d_smartbox_id
     *
     * @param L_d_smartbox_id 
     */
    public synchronized String GetSmartboxId() {
        return this.L_d_smartbox_id;
    }
    
    
    /**
     * Get the Entry_Available_Flag
     *
     * @param L_Entry_Available_Flag 
     */
    public synchronized Boolean GetEntryAvailableFlag() {
        return this.L_Entry_Available_Flag;
    }
    
    
    /**
     * Get the Entry_Available_Flag
     *
     * @param L_d_immediate_action_Flag 
     */
    public synchronized Boolean GetImmediateActionFlag() {
        return this.L_d_immediate_action_Flag;
    }
    
    
    /**
     * Get the Busy_Flag
     *
     * @param L_Busy_Flag 
     */
    public synchronized Boolean GetBusyFlag() {
        return this.L_Busy_Flag;
    }
}
