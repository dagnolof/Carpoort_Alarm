package rs232test;

import com.mysql.cj.util.StringUtils;
import java.sql.DriverManager;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.sql.*;

/*
 
 */

/**
 *
 * @author fdag0
 */
public class SmsHandler {
    
    //Private variables of class SmsHandler
    private JframeRs232TestMain  MainQui;     //// Reference to JframeRs232TestMain.java Main Qui
    
    //Timer Values
    private static final Integer T_Mainloop_Timer = 250;                        //250ms timer value
    private static final Integer T_Wait_Sms_Reply_Timer_Value = 480;            //120s Timer, 480 x 250ms 
    
    private enum E_State {Ms_Start, Ms_Check_Todo_Structure, Ms_Wait_Enter_Sms_Text, Ms_Wait_Tx_Sms_Reply, Ms_Wait_Sms_Reply, Ms_Wait_Read_Sms_Reply, 
    Ms_Store_Sonde_Results, Ms_Set_Smartbox_Err, Ms_Wait, Ms_Clear_Modem_Memory, Ms_Clear_Modem_Memory_Wait_OK, Ms_Done;
    };    
    private E_State Z_State, Z_State_Previous;
    private Timer timer;
    private Date DateTime = new Date();
    private Integer d_nbr_of_sondes;
    private String d_smartbox_id;
    private Integer d_smartbox_id_Int;
    private Integer d_user_id_Int;
    private String d_gsm_nbr;
    private String d_user_id;
    private String d_user_name;
    private String d_alarm_text;
    private int[] Sondes_Array_Idx;      /* Contains index in The Rx Sms where sonde info is found */
    private String[] Sondes_Results;     /* Contains the found sonde results */
    private Integer Z_T_Wait_Sms_Reply_Timer_Counter = 0;
    private Integer Z_T_Wait_Sms_Reply_Retry_Counter = 0;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // Constructor of SmsHandler Class
    public SmsHandler(JframeRs232TestMain L_MainQui){   // L_MainQui is a reference to the calling MainQui
        this.MainQui = L_MainQui;                       // By using MainQui. in this java file, we can use all methodes of the Mainqui
        this.SmsHandlerStart();
    }  
    
    
    /**
     * Cancel the Mainlooptimer
     */
    public void SmsHandlerClose(){
       timer.cancel();
    }
    
    /**
     * Start the modemhandler by scheduling the timer that will trigger the Mainloop
     */
    public void SmsHandlerStart() {
        // Initialise Z_State here. If we place this instruction afther the timer.schedule coinstruction.
        // We get NULL pointer execptions error on the use of this variable in the code !!!!!
        this.Z_State = E_State.Ms_Start;
        this.Z_State_Previous = E_State.Ms_Done;
        
        // Schedule the Mainloop Timer.
        // Schedule the Mainloop Timer, Initial timeout is 2000ms, subsequent timeouts are 250ms
        // We need the initial timeout of 2000ms to let the JframeRs232TestMain initialise.
        // Because once the Mainloop starts we will write a string into the MainQui.WriteInLogfile....
        // Without the initial timeout we get an exeption error in MainQui.WriteInLogfile...
        timer = new Timer();
        timer.schedule(new MainLoop(), 2000, T_Mainloop_Timer);
    }
     
    
    class MainLoop extends TimerTask {
//        private byte[] L_Buffer = new byte[500];
        private Boolean L_State_Busy = false;
        
        public synchronized void run() {
            String L_Time;
            
            if (Z_State.name() == null ? Z_State_Previous.name() != null : !Z_State.name().equals(Z_State_Previous.name())) {
              //L_Time = GetTimeString(); 
              L_Time = genericCode.GetTimeString();
              
              //MainQui.WriteInLogfile(L_Time +  "SmsHandler Z_State  " + Z_State.name() +   MainQui.Z_Nextline); 
              MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", "");
            }
            // MainQui.WriteInLogfile("Z_State  " + Z_State.name() +   MainQui.Z_Nextline);
            Z_State_Previous = Z_State;
            
            
            switch (Z_State) {
                case Ms_Start:
                    //Write SmsHandler startup actions here 
                    Z_T_Wait_Sms_Reply_Timer_Counter = 0;
                    Z_T_Wait_Sms_Reply_Retry_Counter = 0;
                    
                    Z_State = E_State.Ms_Check_Todo_Structure;
                    break;

                
                case Ms_Check_Todo_Structure:
                    //Check if there is an entry available in the todoStructure
                    if (MainQui.todoStructure.GetEntryAvailableFlag()) {
                        //An entry is found, set the Entry Busy flag 
                        MainQui.todoStructure.ChangeBusyFlag(true);

                        // Check for witch application a todo entry is found, Tankmonitor or Gsm_Action 
                        String L_Application = MainQui.todoStructure.GetApplication();

                        switch (L_Application) {
                            case "Tank-Monitor":
                                //Retrieve the Gsm number corresponding to the data found in the todoStructure
                                //In the todoStructure we find d_user_id and d_smartbox_id
                                //Use both inputs to find the Gsm Number out of R_Datastructure
                                L_Time = genericCode.GetTimeString();
                                MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", "  Tank-Monior Action");
                                
                                d_user_id = MainQui.todoStructure.GetUserId();
                                d_user_id_Int = Integer.parseInt(d_user_id);
                                d_smartbox_id = MainQui.todoStructure.GetSmartboxId();
                                d_smartbox_id_Int = Integer.parseInt(d_smartbox_id);

                                d_gsm_nbr = MainQui.todoStructure.GetGsmNr();
                                d_nbr_of_sondes = MainQui.todoStructure.GetNbrOfSondes();
                                d_user_name = MainQui.todoStructure.GetUserName();

                                //Define Sondes_Array_Idx Array that will keep track of the sonde Idx's in the Rx String
                                //+1 Vecause sonde counting starts from 1, array Idx counting starts from 0
                                //Define Sondes_Results to keep track of the sondes results found in the Rx Sms 
                                Sondes_Array_Idx = new int[d_nbr_of_sondes + 1];
                                Sondes_Results = new String[d_nbr_of_sondes + 1];

                                L_Time = genericCode.GetTimeString();
                                //MainQui.WriteInLogfile(L_Time +  "SmsHandler Z_State  " + Z_State.name() + "  d_user_id:  " + d_user_id + "  d_smartbox_id:  " + d_smartbox_id + "  d_gsm_nbr:  " + d_gsm_nbr +  MainQui.Z_Nextline); 
                                MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", "d_user_id:  " + d_user_id + "  d_smartbox_id:  " + d_smartbox_id + "  d_gsm_nbr:  " + d_gsm_nbr);

                                //At this point we know the Gsm_Nbr of the Smartbox connected to the User and smartbox in Question.
                                //We can send the SMS to the smartbox to find out the status of the tanks connected to the smartbox.
                                MainQui.TransmitModemCommand("AT+CMGS=" + "\""  +d_gsm_nbr + "\"");
                                /* Patch out this line to test the Rx message */
                                Z_State = E_State.Ms_Wait_Enter_Sms_Text;
                                
                                break;
                                
                                
                            case "Gsm-Action":
                                //Retrieve the Gsm number, and Alarm_text corresponding to the data found in the todoStructure
                                L_Time = genericCode.GetTimeString();
                                MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", "  Gsm-Action Action");
                                
                                d_gsm_nbr = MainQui.todoStructure.GetGsmNr();
                                d_alarm_text = MainQui.todoStructure.GetAlarmText();
                                
                                //We can send the alarm SMS to the user
                                //MainQui.TransmitModemCommand("AT+CMGS=" + d_gsm_nbr);
                                MainQui.TransmitModemCommand("AT+CMGS=" + "\""  +d_gsm_nbr + "\"");
                                /* Patch out this line to test the Rx message */
                                Z_State = E_State.Ms_Wait_Enter_Sms_Text;
                                
                                break;
                        }

                    }
                    
                    break;

 
                case Ms_Wait_Enter_Sms_Text:
                    //Wait for the ">" character from the modem
                    //Z_State = E_State.Ms_Sent_ATE0_Wait_OK;
                    if (MainQui.rxStructure.GetEnterSmsTextFlag()) {

                        // Check for witch application an sms has to be send, Tankmonitor or Gsm_Action 
                        String L_Application = MainQui.todoStructure.GetApplication();

                        switch (L_Application) {
                            case "Tank-Monitor":
                                //Enter the Sms Text and terminate the string with Ctrl-Z character
                                MainQui.rxStructure.ChangeEnterSmsTextFlag(false);

                                char CtrlZ = 0x1A;
                                MainQui.TransmitModemCommand("#R" + CtrlZ);

                                Z_State = E_State.Ms_Wait_Tx_Sms_Reply;
                                break;

                                
                            case "Gsm-Action":
                                 // Enter the Sms Text and terminate the string with Ctrl - Z character MainQui
                                MainQui.rxStructure.ChangeEnterSmsTextFlag(false);

                                CtrlZ = 0x1A;
                                MainQui.TransmitModemCommand(d_alarm_text + CtrlZ);

                                // In case of an Gsm_Action we only need to send the alarm SMS, there is no reply 
                                // expected, so we are done
                                Z_State = E_State.Ms_Wait_Tx_Sms_Reply;

                                break;

                        }

                    }

                    break;
        
 
                    
                 case Ms_Wait_Tx_Sms_Reply:
                    //Wait for the ">" character from the modem
                    //Z_State = E_State.Ms_Sent_ATE0_Wait_OK;
                    if (MainQui.rxStructure.GetTxSmsReplyReceivedFlag()) {

                        // Check for witch application an sms has to be send, Tankmonitor or Gsm_Action 
                        String L_Application = MainQui.todoStructure.GetApplication();

                        switch (L_Application) {
                            case "Tank-Monitor":
                                //Enter the Sms Text and terminate the string with Ctrl-Z character
                                MainQui.rxStructure.ChangeTxSmsReplyReceivedFlag(false);
                                        
                                Z_State = E_State.Ms_Wait_Sms_Reply;
                                break;

                                
                            case "Gsm-Action":
                                 // Enter the Sms Text and terminate the string with Ctrl - Z character MainQui
                                MainQui.rxStructure.ChangeTxSmsReplyReceivedFlag(false);

                                // In case of an Gsm_Action we only need to send the alarm SMS, there is no reply 
                                // expected, so we are done
                                Z_State = E_State.Ms_Done;

                                break;

                        }

                    }

                    break;                  
                    
                                     
                    
                case Ms_Wait_Sms_Reply:
                    //Wait for Sms Reply "+CMTI:" characters from the modem
                    if (MainQui.rxStructure.getRxSmsFlag()) {
                        //An sms has been received, know we have to read out the Sms
                        //Rx String : +CMTI: "SM",x
                        //We need to filter the x string out and send the AT+CMGR=x command to the modem to read
                        //the receeved sms on the SM, Sim memory, on position x.
                        MainQui.rxStructure.ChangeRxSmsFlag(false);

                        String RxString = MainQui.rxStructure.GetRxString();
                        String L_SmsPosition = RxString.substring(RxString.indexOf(",")+1, RxString.length());
          
                        MainQui.TransmitModemCommand("AT+CMGR=" + L_SmsPosition);
                        //MainQui.TransmitModemCommand("AT+CMGR=4");
                        
                        //19-Feb-2019
                        //SMS reply is received in Time
                        //Clear Z_T_Wait_Sms_Reply_Timer_Counter and also  Z_T_Wait_Sms_Reply_Retry_Counter
                        Z_T_Wait_Sms_Reply_Timer_Counter = 0;
                        Z_T_Wait_Sms_Reply_Retry_Counter = 0;
                        
                        Z_State = E_State.Ms_Wait_Read_Sms_Reply;
                    } else {
                        //We implement a timer to wait for the Sms reply.
                        //In this way we come out of the situation where the Smartbox is not answering for whatever reason
                        Z_T_Wait_Sms_Reply_Timer_Counter++;
                        
                        if (Z_T_Wait_Sms_Reply_Timer_Counter.equals(T_Wait_Sms_Reply_Timer_Value)){
                            Z_T_Wait_Sms_Reply_Timer_Counter = 0;
                            Z_T_Wait_Sms_Reply_Retry_Counter++;
                            
                            if (Z_T_Wait_Sms_Reply_Retry_Counter >= 2){
                                //We already retryed on this Smartbox Id
                                //- Set error indication in t_smartboxs
                                Z_T_Wait_Sms_Reply_Retry_Counter = 0;
                                Z_State = E_State.Ms_Set_Smartbox_Err;
/*                                Set_Smartbox_Error(d_smartbox_id_Int, "No Reply on Sms");
                                 
                                L_Time = genericCode.GetTimeString();
                                MainQui.WriteInLogfile(L_Time + "SmsHandler Z_State,  " + Z_State.name() + " Sms_Retry_Counter = 2" + MainQui.Z_Nextline);
            
                                Z_State = E_State.Ms_Clear_Modem_Memory;  */
                            } else {
                                //Retry counter not yet reached.
                                //Scan the todo table again for actions
                                Z_State = E_State.Ms_Check_Todo_Structure;
                                Z_T_Wait_Sms_Reply_Timer_Counter = 0;
                            }
                        }
                    
                    }
                    
                    break;
                    
                    
                case Ms_Wait_Read_Sms_Reply:
                    //Wait for Read Sms Reply "+CMGR:" characters from the modem
                    if (MainQui.rxStructure.GetReadSmsFlag()) {
                        //The contents of the received sms has been read.
                        //Rx String : +CMGR: ...
                        //RX: +CMGR: "REC UNREAD","+32493408998",,"18/09/29,10:09:38+08"Oilview smartbox2; Manually inquiry; 69%=6900L, 82%=8200L, E008, 16%=39800L; No alarm; 521OK
                        //We need to filter out the measurements of the different sensors connected to the smartbox. It gets more complicated if there are sensors in Error like it is 
                        //in the above exaample. Sensor 3 is in error state E008.
                        MainQui.rxStructure.ChangeReadSmsFlag(false);

                        String RxString = MainQui.rxStructure.GetRxString();                    
                        Handle_Incomming_Sms(RxString);
                       
                        Z_State = E_State.Ms_Store_Sonde_Results;   
                    }

                    break;
                    

                case Ms_Store_Sonde_Results:
                    //All paramters to store the sonde results are defined at this point.
                    //For code redability we will call a Store_Sonde_Results (...) procedure.
                    Z_State = E_State.Ms_Wait;
                    
                    Store_Sonde_Results(d_user_id_Int, d_user_name, d_smartbox_id_Int, d_nbr_of_sondes, Sondes_Results);  
                    Z_State = E_State.Ms_Clear_Modem_Memory;
                    break;

                    
                case Ms_Set_Smartbox_Err:
                    //All paramters to store the sonde results are defined at this point.
                    //For code redability we will call a Store_Sonde_Results (...) procedure.
                    Z_State = E_State.Ms_Wait;
                    
                    Set_Smartbox_Error(d_smartbox_id_Int, d_user_name, "No Reply on Sms");
                                 
                    L_Time = genericCode.GetTimeString();
                    //MainQui.WriteInLogfile(L_Time + "SmsHandler Z_State,  " + Z_State.name() + " Sms_Retry_Counter = 2" + MainQui.Z_Nextline);
                    MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", " Sms_Retry_Counter = 2");
                    Z_State = E_State.Ms_Clear_Modem_Memory; 
                    break;
                    

                case Ms_Wait:
                    //State where we do nothing.
                    //This state is enterred when a procedure action might take longer to execute than the Loop Timer defined for this class.

                    break;
                  
                    
                case Ms_Clear_Modem_Memory:
                    //The Rx SMS is treated. This SMS is stored in the memory of the TELIT modem. To overcome a memory full 
	            //condition we will clear the memory of the Telit Modem. */
                    MainQui.TransmitModemCommand("AT+CMGD=1,4");          
                    Z_State = E_State.Ms_Clear_Modem_Memory_Wait_OK;

                    break;

                    
                case Ms_Clear_Modem_Memory_Wait_OK:
                    if (MainQui.rxStructure.GetRxOKFlag()) {
                        // "OK" String is received on the RS232 Port
                        // Clear the RxOKFlag/RxDataFlag
                        MainQui.rxStructure.ChangeRxOKFlag(false);
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        Z_State = E_State.Ms_Done;
                    }

                    break;
                    

                case Ms_Done:
                    //Clear flags that where set during execution of the todo actions
                    MainQui.todoStructure.ChangeBusyFlag(false);
                    MainQui.todoStructure.ChangeEntryAvailableFlag(false);
                    Z_State = E_State.Ms_Check_Todo_Structure;

                    break;
            }
        }
    }   
    
    
    private void Handle_Incomming_Sms(String Rx_Sms) {
        //Handle the incomming sms text
        //First we search all occurences of a sonde in error. In this case string "E0" will be present in the Received Sms.
        //We store the results in array Sondes_Array_Idx
        //Arrays.sort(Sondes_Array_Idx);
        Integer L_Sonde_Counter = 0;
        String L_Rx_String = Rx_Sms;
        Integer L_FromIndex = 0;
        Boolean L_Continue = true;
        Integer L_FoundIndex = 0;

        while (L_Continue) {
            L_FoundIndex = L_Rx_String.indexOf("E0", L_FromIndex);

            if (L_FoundIndex != -1) {
                L_Sonde_Counter++;
                
                //"E0" occurence found, store the corresponding index in the Sondes_Array_Idx
                Sondes_Array_Idx[L_Sonde_Counter] = L_FoundIndex;
                
                //The next seach should start from here.
                L_FromIndex = L_FoundIndex + 1;
            } else L_Continue = false;
        }        
        
        //Search for all occurence of sonde values in the Received Sms. Sonde Values are identified by string "%="
        L_FromIndex = 0;
        L_Continue = true;
        L_FoundIndex = 0;
        
         while (L_Continue) {
            L_FoundIndex = L_Rx_String.indexOf("%=", L_FromIndex);

            if (L_FoundIndex != -1) {
                L_Sonde_Counter++;
                
                //"%=" occurence found, store the corresponding index in the Sondes_Array_Idx
                Sondes_Array_Idx[L_Sonde_Counter] = L_FoundIndex;
                
                //The next seach should start from here.
                L_FromIndex = L_FoundIndex + 1;
            } else L_Continue = false;
        }               

        //All sondes are found
        //Sorteer de Sondes_Array_Idx in Stijgende volgorde
        Arrays.sort(Sondes_Array_Idx);
        
        //Check if the found number of sondesin the Received Sms is equal to the nbr_of_sondes stored in the database.
        //If equal we go on with extracting data, if not we mark all sondes in an error condition.
        if (L_Sonde_Counter != d_nbr_of_sondes) {

        } else {//For all sondes extract sonde data out of received sms
            //RX: +CMGR: "REC UNREAD","+32493408998",,"18/09/29,10:09:38+08"Oilview smartbox2; Manually inquiry; 69%=6900L, 82%=8200L, E008, 16%=39800L; No alarm; 521OK
            L_Sonde_Counter = 0;
            L_FromIndex = 0;
            String L_Sonde_Item;
            String L_Sonde_Results = "";
            Integer L_Komma_Idx;

            for (L_Sonde_Counter = 1; L_Sonde_Counter <= d_nbr_of_sondes; L_Sonde_Counter++) {
                L_Sonde_Item = L_Rx_String.substring(Sondes_Array_Idx[L_Sonde_Counter]);

                //Find the Komma Index in the Sonde_Item subscring. If it is the last sonde item in the received sms, then the sonde separator is 
                //the ";" else the separator is equal to ",";
                L_Komma_Idx = L_Sonde_Item.indexOf(",");
                if (L_Komma_Idx == -1) L_Komma_Idx = L_Sonde_Item.indexOf(";");

                //Check if the Sonde result starts with % or with E, it matters conserning the startindex
                //if (L_Sonde_Item.substring(0) == "E") {
                if (L_Sonde_Item.startsWith("E")) {
                    L_FromIndex = 0;
                } else {
                    L_FromIndex = 2;
                }

                L_Sonde_Item = L_Sonde_Item.substring(L_FromIndex, L_Komma_Idx);
                L_Sonde_Results = L_Sonde_Results + L_Sonde_Item + ",";
                
                Sondes_Results[L_Sonde_Counter] = L_Sonde_Item;
            }
            
            //L_Time = GetTimeString(); 
            String L_Time = genericCode.GetTimeString();
            //MainQui.WriteInLogfile(L_Time + "SmsHandler Z_State,  " + Z_State.name() + "  Handle_Incomming_Sms  Sonde Results : " + L_Sonde_Results + MainQui.Z_Nextline);
            MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", "Handle_Incomming_Sms  Sonde Results : " + L_Sonde_Results);
        }
    }
 
    

    private void Store_Sonde_Results(Integer d_user_id_Int, String d_user_name, Integer d_smartbox_id_Int, Integer d_nbr_of_sondes, String[] Sondes_Results) {
        //In this procedure we store the Sondes_Results in to the database table t_sonde_results
        Integer L_Sonde_Counter = 0;
        String Query ="";
        
        //Create a sql date object so we can use it in our INSERT statement, define Date and Time has separate Items
        //They are also stored in separate colomns in the database table
        Calendar calendar = Calendar.getInstance();
        java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
        java.sql.Time startTime = new java.sql.Time(calendar.getTime().getTime());
       
        try {
            //First we open the database 
            // Create an instance of the Database.java class
            Database database = new Database(MainQui);

            //Connect to Fuelmonitor mysql database
            database.DatabaseConnect();

            //Query table t_todo
            //Define the Sql Statement
            //database.DB_Statement = database.DB_Connect.createStatement();
            //Store the results for all sondes
            for (L_Sonde_Counter = 1; L_Sonde_Counter <= d_nbr_of_sondes; L_Sonde_Counter++) {
                //String Query = "insert into 't_sonde_results'`(`d_user_id`, `d_user_name`, `d_smartbox_id`, `d_sonde_id`, `d_tank_inhoud`) VALUES(d_user_id, d_user_name, d_smartbox_id_Int, L_Sonde_Counter, Sondes_Results[L_Sonde_Counter]) ";
                Query = "insert into t_sonde_results (d_user_id, d_user_name, d_smartbox_id, d_sonde_id, d_tank_inhoud, d_date, d_time) VALUES(?,?,?,?,?,?,?)";

                //// create the mysql insert preparedstatement
                PreparedStatement preparedStmt = database.DB_Connect.prepareStatement(Query);
                preparedStmt.setInt(1, d_user_id_Int);
                preparedStmt.setString(2, d_user_name);
                preparedStmt.setInt(3, d_smartbox_id_Int);
                preparedStmt.setInt(4, L_Sonde_Counter);
                preparedStmt.setString(5, Sondes_Results[L_Sonde_Counter]);
                preparedStmt.setDate(6, startDate);
                preparedStmt.setTime(7, startTime);

                // execute the preparedstatement
                preparedStmt.execute();

                //User Feedback in log file
                String L_Time = genericCode.GetTimeString();
                //MainQui.WriteInLogfile(L_Time + "SmsHandler Z_State,  " + Z_State.name() + "  Handle_Incomming_Sms  Insert in t_sonde_results : " + "d_user_id: " + d_user_id_Int + "  d_user_name: " + d_user_name + "  d_smartbox_id: " + d_smartbox_id_Int + "  d_sonde_id: " + L_Sonde_Counter + "  d_tank_inhoud: " + Sondes_Results[L_Sonde_Counter] + "  d_date: " + startDate + "  d_time: " + startTime + MainQui.Z_Nextline);
                MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", "Handle_Incomming_Sms  Insert in t_sonde_results : " + "d_user_id: " + d_user_id_Int + "  d_user_name: " + d_user_name + "  d_smartbox_id: " + d_smartbox_id_Int + "  d_sonde_id: " + L_Sonde_Counter + "  d_tank_inhoud: " + Sondes_Results[L_Sonde_Counter] + "  d_date: " + startDate + "  d_time: " + startTime);
            }

            //Close the database
            database.DB_Connect.close();

        } catch (Exception ex) {
            System.out.println("SmsHandler/Store_Sonde_Results/Erp01: " + ex);
        } finally {
        }  
    }
    
    
    
    private void Set_Smartbox_Error(Integer d_smartbox_id_Int, String d_user_name, String L_Err_Descr){
        //Create a sql date object so we can use it in our INSERT statement, define Date and Time has separate Items
        //They are also stored in separate colomns in the database table
        String Query ="";
        
        Calendar calendar = Calendar.getInstance();
        java.sql.Date L_Err_Date = new java.sql.Date(calendar.getTime().getTime());
        java.sql.Time L_Err_Time = new java.sql.Time(calendar.getTime().getTime());
       
        try {
            //First we open the database 
            // Create an instance of the Database.java class
            Database database = new Database(MainQui);

            //Connect to Fuelmonitor mysql database
            database.DatabaseConnect();

            //Query table t_todo
            //Define the Sql Statement
            //database.DB_Statement = database.DB_Connect.createStatement();
            //Store the results for all sondes
           //for (L_Sonde_Counter = 1; L_Sonde_Counter <= d_nbr_of_sondes; L_Sonde_Counter++) {
                //String Query = "insert into 't_sonde_results'`(`d_user_id`, `d_user_name`, `d_smartbox_id`, `d_sonde_id`, `d_tank_inhoud`) VALUES(d_user_id, d_user_name, d_smartbox_id_Int, L_Sonde_Counter, Sondes_Results[L_Sonde_Counter]) ";
                Query = "insert into t_errors (d_user_name, d_smartbox_id, d_date, d_time, d_err_descr) VALUES(?,?,?,?,?)";

                //// create the mysql insert preparedstatement
                PreparedStatement preparedStmt = database.DB_Connect.prepareStatement(Query);
                preparedStmt.setString(1, d_user_name);
                preparedStmt.setInt(2, d_smartbox_id_Int);
                preparedStmt.setDate(3, L_Err_Date);
                preparedStmt.setTime(4, L_Err_Time);
                preparedStmt.setString(5, L_Err_Descr);

                // execute the preparedstatement
                preparedStmt.execute();

                //User Feedback in log file
                String L_Time = genericCode.GetTimeString();
                //MainQui.WriteInLogfile(L_Time + "SmsHandler Z_State,  " + Z_State.name() + "  Set Error Indicator for Smartbox Id : " + d_smartbox_id_Int + MainQui.Z_Nextline);
                MainQui.Write_In_Logfile(L_Time, "SmsHandler.java", Z_State.name(), "", "Set Error Indicator for Smartbox Id : " + d_smartbox_id_Int);
           /* }*/

           
            //Set error indicator in tabel t_smartboxs
            database.DB_Statement = database.DB_Connect.createStatement();
            Query = "UPDATE t_smartboxs SET d_error_indicator=1 WHERE d_user_name = '" + d_user_name + "'" + " AND " + "d_smartbox_id=" + d_smartbox_id;
            database.DB_Statement.executeUpdate(Query);
           
           
            //Close the database
            database.DB_Connect.close();

            
            
            
            
            
            
            
            
        } catch (Exception ex) {
            System.out.println("SmsHandler/Set_Smartbox_Error/Erp02: " + ex);
        } finally {
        }    
 
        
        
    }
}



