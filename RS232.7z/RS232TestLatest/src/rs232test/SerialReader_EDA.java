/*
 * By implementing SerialReader in his own class, we can use local variables to keep track
 * of the reveived data. Else we had to user Glabal variables. Once the JframeRs232TestMain main frame class
 * creat's an instance of the SerialReader class, the private variables will always exist, even when more than 
 * one serial portevent is triggered.
 */
package rs232test;

//import gnu.io.SerialPortEvent;
//import gnu.io.SerialPortEventListener;
import com.fazecast.jSerialComm.*;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fdag0
 */
public class SerialReader_EDA implements SerialPortDataListener {
    // Local private variables for SerialReader class
    @Override
   public int getListeningEvents() { return SerialPort.LISTENING_EVENT_DATA_AVAILABLE; }
   
    private SerialPort In;
    private byte[] L_SerialReaderBuffer = new byte[200];
    private int L_Data, L_Len = 0;
    String S_Rx_Buffer = "";
    private JframeRs232TestMain MainQui;     // Reference to JframeRs232TestMain.java Main Qui
    Timer T_RxComplete;
    boolean L_PartlyRxDataFlag = false;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();

    // Constructor of SerialReader Class
    public SerialReader_EDA(SerialPort in, JframeRs232TestMain L_MainQui) {   // Reference to JframeRs232TestMain.java Main Qui
        this.In = in;
        MainQui = L_MainQui;   // By using MainQui. in this java file, we can use all methodes of the Mainqui

        // Define an instance of the RxComplete Timer
        //T_RxComplete = new Timer();
    }

    @Override
    public void serialEvent(SerialPortEvent event) {
        if (event.getEventType() != SerialPort.LISTENING_EVENT_DATA_AVAILABLE) {
            return;
        }
        //byte[] newData = new byte[In.bytesAvailable()];
        //int numRead = In.readBytes(newData, newData.length);
        //System.out.println("Read " + numRead + " bytes.");
        if (S_Rx_Buffer.length() == 0) {
            //If No data is received yet,  we start an overall Timer. The RxHandler() will treat the received message.
            //The timer length is set from 500ms afther we have read an incomming SMS message.
            //T_RxComplete.schedule(new SerialReader_MEDR.RxHandler(), 850);
        }
                
        int Number_Bytes_read = In.readBytes(L_SerialReaderBuffer, In.bytesAvailable());
        L_SerialReaderBuffer = RemoveCrLf(L_SerialReaderBuffer);
        String S_SerialReaderBuffer = new String(L_SerialReaderBuffer, 0, L_SerialReaderBuffer.length);
        S_Rx_Buffer = S_Rx_Buffer + S_SerialReaderBuffer;
        
        //String L_Time = genericCode.GetTimeString();
        //MainQui.Write_In_Logfile(L_Time, "SerialReader.java", "", "", "SerialReader RX: " + (new String(newData, 0, numRead)));

        //int Number_Bytes_read = In.readBytes(L_SerialReaderBuffer, numRead);
 
        String L_Time = genericCode.GetTimeString();
        MainQui.Write_In_Logfile(L_Time, "SerialReader_EDA.java", "", "", "SerialEvent RX: " + S_Rx_Buffer);
    }
    
    
    
 /*   public synchronized void serialEvent(SerialPortEvent oEvent) {
        if (oEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
            try {
                // ..readline() on the buffered reader input, only input data terminated with \n is seen as valid data.
                // String inputline = R_RS232_Buffered_Reader_Input.readLine();

                // RS232 data is send byte by byte. We need to collect the received bytes in a buffer, and 
                // accept the buffer after a \n characther is received.
                L_Data = this.In.read();

                if (L_Len == 0) {
                    // If No data is received yet,  we start an overall Timer. The RxHandler() will treat the received message.
                    // The timer length is set from 250 to 850ms afther we have read an incomming SM message.
                    // With this timer set on 250ms the incoming sms message is received in 3 parts. With this timer set on 850ms
                    // We only receive one Rx String. This is easier for parcing the received string. But it makes the treatment of the 
                    // AT commands over the RS232 connection a little bit slower.
                    T_RxComplete.schedule(new RxHandler(), 850);
                }

                L_SerialReaderBuffer[L_Len++] = (byte) L_Data;
            } catch (Exception e) {
                System.err.println(e.toString());

            }
            // Ignore all the other eventTypes, but you should consider the other ones
        }
    }  */

    class RxHandler extends TimerTask {

        public synchronized void run() {
            //Copy the Received RS232 Message intp the MainQui.rxStructure
            //6-Dec-2018
            //We have a case where we receive a blank RS232 message, probably due to a RS232 message on a size limit.
            //We add a protection that we only update MainQui.rxStructure if the RxDataFlag is False. Being false it means
            //that de modemhandler treated the previous RS232 message.
            ////////////////////////////////////////////////////////////////////
            //8-Dec-2018
            //We have a verry verry strange behaviour of the code regarding the received RS232 data being placed in 
            //L_SerialReaderBuffer in the serialEvent class, and afterwards being copied into
            //MainQui.rxStructure.CopyRxBuffer(L_SerialReaderBuffer); in the Timertask Class
            //
            //After program startup, only the first received reply is copied like it should. First in L_SerialReaderBuffer
            //in the event handler, and after 850ms timeout the L_SerialReaderBuffer is copied into MainQui.rxStructure...
            //
            //the reply received on the second command is handled verry verry strange.
            //In the eventhandler the received bytes are stored in L_SerialReaderBuffer AND ALSO in MainQui.rxStructure... !!!!!!!
            //How can this be, this is what i see placing watch breakpoints, and also we discovered this problem after 
            //an error on the reply of the AT+CMGR=1 command, to read out the received SMS contents.
            //Normaly the reply should be "RX: +CMGR: "REC UNREAD","+32493408998",,"18/09/29...."
            //But we see sometimes        "RX: \r\nMGR: "REC UNREAD","+32493408998",,"18/09/29..."
            //Or                          "RX: MGR: "REC UNREAD","+32493408998",,"18/09/29..."
            //
            //The first characters of the reply are overwritten. 
            //Therefore we started looking in to this behaviour and found this malfunction.
            //
            //To solve this we replaced the MainQui.rxStructure.L_Buffer with MainQui.rxStructure.L_RxString
            //Meaning that in Timertask Class we convert L_SerialReaderBuffer into a RxString. Is is this RxString that we 
            //copy into the MainQui.rxStructure.  After this change the behaviour was gone !!!!!!!!!
            ////////////////////////////////////////////////////////////////////            
            if (!(MainQui.rxStructure.GetRxDataFlag())) {
                L_SerialReaderBuffer = RemoveCrLf(L_SerialReaderBuffer);
                
                String L_Time = genericCode.GetTimeString();
                //MainQui.WriteInLogfile(L_Time + "SerialReader RX: " + (new String(L_SerialReaderBuffer, 0, L_Len)) + MainQui.Z_Nextline);
                MainQui.Write_In_Logfile(L_Time, "SerialReader.java", "", "", "SerialReader RX: " + (new String(L_SerialReaderBuffer, 0, L_Len)));

                String RxString = new String(L_SerialReaderBuffer);
                RxString = RxString.trim();
                // A reply on a send command is completely received 
                // Copy the received RS232 in the RxTxRs232Structure array, Set the RxDataFlag
//              MainQui.rxStructure.CopyRxBuffer(L_SerialReaderBuffer);
                MainQui.rxStructure.CopyRxString(RxString);
                // MainQui.rxStructure.ChangeRxDataFlag(true);

                //Read the Rx buffer back for test
//                L_SerialReaderBuffer = MainQui.rxStructure.GetRxBuffer();
//              String RxString = new String(L_SerialReaderBuffer);
//              RxString = RxString.trim();
                
//                L_Time = genericCode.GetTimeString();
//                MainQui.WriteInLogfile(L_Time + "SerialReader RX: " + RxString + "  Rx Length :" + L_Len  + "RxString Length: " + RxString.length()+ MainQui.Z_Nextline);
                
                
                // Clear the Length of Z_Buffer
                L_Len = 0;

//                String RxString = new String(L_SerialReaderBuffer);
                //String Z_OK = new String("OK");
                if (RxString.contains("OK")) {
                    MainQui.rxStructure.ChangeRxOKFlag(true);
                }

                // Set the RxDataFlag
                MainQui.rxStructure.ChangeRxDataFlag(true);
                /*            Integer L_1 = 0;
            
            if (MainQui.rxStructure.GetTracerOnFlag()){
              Integer I = 0;          
            }*/
            }
        }

        private synchronized byte[] RemoveCrLf(byte[] L_Buffer) {
            byte[] Temp_Buffer = new byte[500];
            int L_C = 0;

            for (int i = 0; i < L_Len; i++) {
                if ((L_Buffer[i] != '\n') && (L_Buffer[i] != '\r')) {
                    Temp_Buffer[L_C] = L_Buffer[i];
                    L_C++;
                }

            }

            return Temp_Buffer;
        }
    }

    /* 
    private void HeartBeatTimer() {
        Timer timer;

        timer = new Timer();
        timer.schedule(new HeartBeatTask(), 0, 2000);
    }
    
    
    class HeartBeatTask extends TimerTask {
  
        public void run() {
            String HeartbeatCommand = "AT";

            //this.Z_RS232_Output.write((this.jTextFieldCommandToTx.getText() + "\r").getBytes());
            MainQui.TransmitModemCommand(HeartbeatCommand);

        }
    }*/
    
    private synchronized byte[] RemoveCrLf(byte[] L_Buffer) {
        byte[] Temp_Buffer = new byte[500];
        int L_C = 0;

        for (int i = 0; i < L_Buffer.length; i++) {
            if ((L_Buffer[i] != '\n') && (L_Buffer[i] != '\r')) {
                Temp_Buffer[L_C] = L_Buffer[i];
                L_C++;
            }

        }

        return Temp_Buffer;
    }
}