/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs232test;

import com.mysql.cj.util.StringUtils;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


// Constructor of Database Class
public class Database {

    // Private Variables
    private JframeRs232TestMain MainQui;  // Reference to JframeRs232TestMain.java Main Qui
    private JframeDatabase Qui_Database_Reference;
    // DB Logon
    private static final String S_Mysql_Driver = "com.mysql.jdbc.Driver";
    private static final String S_Connect = "jdbc:mysql://ID201347_fuelmonitor.db.webhosting.be/ID201347_fuelmonitor";
    private static final String S_Userid = "ID201347_fuelmonitor";
    private static final String S_Password = "vbd3agf2223";
    // Connection 
    //private Connection DB_Connect = null;
    //private Statement DB_Statement;
    //private ResultSet DB_Resultset1;
    public Connection DB_Connect = null;
    public Statement DB_Statement;
    public ResultSet DB_Resultset1;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // Constructor of Database Class
    public Database(JframeRs232TestMain L_MainQui, JframeDatabase L_Qui_Database_Reference) {
        this.MainQui = L_MainQui; 
        this.Qui_Database_Reference = L_Qui_Database_Reference;
    }
  
    
    // Overload Constructor of Database Class
    public Database(JframeRs232TestMain L_MainQui){
        this.MainQui = L_MainQui; 
    }
    
  
    public void DatabaseConnect() {
        //methode that connects to the Mysql FuelMonitor Database
        try {
          //DB_Connect = DriverManager.getConnection(S_Connect + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC" + "&useSSL=false", S_Userid, S_Password);
          //26/nov/2018 
          //...serverTimezone=UTC"
          //Een sensor time occurence wordt in mysql database aangegeven als 1 uur minder !!!!
          //Dit is opgelost door ...serverTimezone=CET   op CET te plaatsen.
          //Ik weet niet of dit een correte oplossing is, maar het werkt wel.
          //Deze verandering onthouden voor later als het winteruur terug wordt aangepast naar zomeruur.
            DB_Connect = DriverManager.getConnection(S_Connect + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=true&serverTimezone=CET" + "&useSSL=false", S_Userid, S_Password);
            String L_Time = genericCode.GetTimeString();
            //MainQui.WriteInLogfile(L_Time + "Connection to Fuelmonitor Database OK" + MainQui.Z_Nextline);
            MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Connection to Fuelmonitor Database OK");
        } catch (Exception ex) {
            System.out.println("Error01: " + ex);
            String L_Time = genericCode.GetTimeString();
            MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Connection to Fuelmonitor Database NOK");
        } finally {
        }
    }
    
    
    public void DatabaseOpen() {
        // Connect to the Fuel Monitor Database
        int L_User_Counter = 1;
        int L_Nbr_Of_Users = 0;
        int L_i;
      
        try {
            //DB_Connect = DriverManager.getConnection(S_Connect + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC" + "&useSSL=false", S_Userid, S_Password);
            //MainQui.WriteInLogfile("Connection to Fuelmonitor Database OK" + MainQui.Z_Nextline);
            this.DatabaseConnect();
           
            // Define the Sql Statement
            DB_Statement = DB_Connect.createStatement();

            // Count the number of entrys on t_users 
            // +1, because the array index start from 0.
            // The id entry in the database tabels start from 1.
            // By adding one the array index corresponds with the datase t_users.d_id
            String Query = "select * from t_users";
            DB_Resultset1 = DB_Statement.executeQuery(Query);
            DB_Resultset1.last();
            L_Nbr_Of_Users = DB_Resultset1.getRow() + 1;

            // Now we know the number of users, we can create the array that will keep trac of the userdata in a M_DataStructure
            MainQui.R_Datastructure = new M_DataStructure[L_Nbr_Of_Users];
            
            DB_Resultset1.beforeFirst();

            while (DB_Resultset1.next()) {
                String Userid = DB_Resultset1.getString("d_user_id");
                String UserName = DB_Resultset1.getString("d_user_name");
                MainQui.R_Datastructure[L_User_Counter] = new M_DataStructure(Userid, UserName);
                L_User_Counter++;

                //System.out.println("Out of t_users:  " + Userid + "   " + UserName);
                //MainQui.WriteInLogfile("Out of t_users:  " + Userid + "   " + UserName + MainQui.Z_Nextline);
                String L_Time = genericCode.GetTimeString();
                MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Out of t_users:  " + Userid + "   " + UserName);
            }

            // Find For Every User the number of Smartboxs 
            Query = "SELECT t_users.d_user_name, count(t_smartboxs.d_user_name) AS nbr_of_smartboxs ";
            Query = Query + "FROM t_users LEFT JOIN t_smartboxs ON t_users.d_user_name LIKE t_smartboxs.d_user_name GROUP BY t_users.d_user_id";

            DB_Resultset1 = DB_Statement.executeQuery(Query);

            L_User_Counter = 1;

            while (DB_Resultset1.next()) {
                String UserName = DB_Resultset1.getString("t_users.d_user_name");
                String Nbr_Of_Smartboxs = DB_Resultset1.getString("nbr_of_smartboxs");

                //System.out.println("Username:  " + UserName + "   Nbr_Of_Smartboxs:  " + Nbr_Of_Smartboxs);
                //MainQui.WriteInLogfile("Username:  " + UserName + "   Nbr_Of_Smartboxs:  " + Nbr_Of_Smartboxs + MainQui.Z_Nextline);
                String L_Time = genericCode.GetTimeString();
                MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Username:  " + UserName + "   Nbr_Of_Smartboxs:  " + Nbr_Of_Smartboxs);
                
                MainQui.R_Datastructure[L_User_Counter].Set_Nbr_Of_Smartboxs(Nbr_Of_Smartboxs);

                L_User_Counter++;
            }

            // For all users find the smartbox info, id, Gsm-Nbr, Nbr_Of_Sondes belonging to that smartbox
            //System.out.printf("Index\tUser-Name\n");

            for (int d_user_id = 1; d_user_id < MainQui.R_Datastructure.length; d_user_id++) {
                String UserName = MainQui.R_Datastructure[d_user_id].Get_UserName();

                //System.out.printf("%d\t%s\n", d_user_id, UserName);
                //MainQui.WriteInLogfile("User_Id:  " + d_user_id + "   Username:  " + UserName  + MainQui.Z_Nextline);
                String L_Time = genericCode.GetTimeString();
                MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "User_Id:  " + d_user_id + "   Username:  " + UserName);
                
                
                // Query t_smartboxs to find Gsm_Nbr for every smartbox belonging to the user
                Query = "SELECT d_smartbox_id, d_gsm_nr FROM t_smartboxs WHERE d_user_name = '" + UserName + "'";
                DB_Resultset1 = DB_Statement.executeQuery(Query);

                while (DB_Resultset1.next()) {
                    String d_smartbox_id = DB_Resultset1.getString("d_smartbox_id");
                    String d_gsm_nr = DB_Resultset1.getString("d_gsm_nr");

                    //System.out.println("d_smartbox_id:  " + d_smartbox_id + "   d_gsm_nr:  " + d_gsm_nr);
                    //MainQui.WriteInLogfile("d_smartbox_id:  " + d_smartbox_id + "   d_gsm_nr:  " + d_gsm_nr  + MainQui.Z_Nextline);
                    L_Time = genericCode.GetTimeString();
                    MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "d_smartbox_id:  " + d_smartbox_id + "   d_gsm_nr:  " + d_gsm_nr);
                    
                    MainQui.R_Datastructure[d_user_id].Set_Gsm_Nbr(d_smartbox_id, d_gsm_nr);
                }
            }

            // For All users find the number of sensors connected to every smartbox belonging to that user.
            // System.out.printf("Index\tUser-Name\n");
            for (int d_user_id = 1; d_user_id < MainQui.R_Datastructure.length; d_user_id++) {
                String UserName = MainQui.R_Datastructure[d_user_id].Get_UserName();
                Integer Nbr_Of_Smartboxs = MainQui.R_Datastructure[d_user_id].Get_Nbr_Of_Smartboxs();
                
                //System.out.printf("%d\t%s\n", d_user_id, UserName);
                //MainQui.WriteInLogfile("User_Id:  " + d_user_id + "   Username:  " + UserName  + MainQui.Z_Nextline);
                String L_Time = genericCode.GetTimeString();
                MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "User_Id:  " + d_user_id + "   Username:  " + UserName);

                Nbr_Of_Smartboxs = MainQui.R_Datastructure[d_user_id].Get_Nbr_Of_Smartboxs();

                for (Integer L_Smartbox_Id = 1; L_Smartbox_Id <= Nbr_Of_Smartboxs; L_Smartbox_Id++) {
                    // Query t_sondes  to find the number of sondes for eatch d_smartbox_id belonging to the user
                    Query = "SELECT Count(d_sonde_id) AS Nbr_Of_Sondes FROM t_sondes WHERE d_user_name = '" + UserName + "'" + "AND " + "d_smartbox_id=" + L_Smartbox_Id;
                    DB_Resultset1 = DB_Statement.executeQuery(Query);

                    while (DB_Resultset1.next()) {
                        String d_nbr_of_sondes = DB_Resultset1.getString("Nbr_Of_Sondes");
                        //String d_gsm_nr = DB_Resultset1.getString("d_gsm_nr");

                        //System.out.println("Smartbox-id: " + L_Smartbox_Id + "    d_Nbr_Of_Sondes:  " + d_nbr_of_sondes);
                        //MainQui.WriteInLogfile("Smartbox-id: " + L_Smartbox_Id + "    d_Nbr_Of_Sondes:  " + d_nbr_of_sondes  + MainQui.Z_Nextline);
                        L_Time = genericCode.GetTimeString();
                        MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Smartbox-id: " + L_Smartbox_Id + "    d_Nbr_Of_Sondes:  " + d_nbr_of_sondes);
                        
                        //MainQui.R_Datastructure[d_user_id].Set_Gsm_Nbr(d_smartbox_id, d_gsm_nr);
                        //MainQui.R_Datastructure[d_user_id].Set_Nbr_Of_Sondes(L_Smartbox_Id, d_nbr_of_sondes);
                        MainQui.R_Datastructure[d_user_id].Set_Nbr_Of_Sondes(L_Smartbox_Id, d_nbr_of_sondes);
                    }

                }
            }
            
            // Enable menu item database view enable flag
            this.Qui_Database_Reference.Set_Database_View_Enable_Flag();
            
            //Set the database Parced Flag
            this.MainQui.systemStructure.SetDatabaseParcedFlag(true);
            this.MainQui.HandleDatabaseParcedState();
            
            //Close the database
            DB_Connect.close();
            DB_Statement.close();
            DB_Resultset1.close();
            String L_Time = genericCode.GetTimeString();
            //MainQui.WriteInLogfile(L_Time + "Connection to Fuelmonitor Database Closed"  + MainQui.Z_Nextline);
            MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Connection to Fuelmonitor Database Closed");
            
        } catch (Exception ex) {
            System.out.println("Error02: " + ex);
        } finally {
        }
    }
    
    /*
    public void databaseView() {
        /*
        We queried the fuelmonitor database inthe mysql database, into an internal structure in the java program
        With this view methode we are going to display yhe internal datastrucure to verify the integrity of the data.
        It is based on this internal data that we send sms's to the different smartbox's.
         */
        
        
        
    /*    
    }*/
    
    
    
}
