/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs232test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

/**
 *
 * @author fdag0
 */
public class LoggingHandler {

    //Private variables of class LoggingHandler
    private JframeRs232TestMain  MainQui;     //// Reference to JframeRs232TestMain.java Main Qui
    String Z_LogFileName;
    String Z_Logging_Directory;
 //   BufferedWriter bw;
    
    
     // Constructor of ModemHandler Class
    public LoggingHandler(JframeRs232TestMain L_MainQui) {   // L_MainQui is a reference to the calling MainQui
        this.MainQui = L_MainQui;                            // By using MainQui. in this java file, we can use all methodes of the Mainqui
    }
    
    
    
    /**
     * Create Log file directoryLogfile
     */
    public void Create_Logfile_Directory(){
       //Empty File name so that there is only the directory in L_Path
       //String L_Filename = "";
       //File f = new File(L_Filename); 
       //String L_Path = f.getAbsolutePath();
       
       //Z_Logging_Directory is defined Global, so that it can be used in other procedures in this class
       //Z_Logging_Directory = L_Path + "\\Logging"; 
       Z_Logging_Directory = "/mnt/shared_drive/Java_Projects/RS232Test/Logging"; 
        
       File f_logging_Directory = new File(Z_Logging_Directory);
       
       //If the logging directory does not exist, it will be created at first program startup
       if (!f_logging_Directory.exists()){
           f_logging_Directory.mkdir();
       }
    }       
    
    
    /**
     * Open the Log file based on the current Date
     */
    public void Write_Logfile(String L_DateTime) {
        Calendar calendar = Calendar.getInstance();
        java.sql.Date Date = new java.sql.Date(calendar.getTime().getTime());
        Z_LogFileName = Date + ".log";

        BufferedWriter bw = null;

        try {
            FileWriter fw = new FileWriter(new File(Z_Logging_Directory, Z_LogFileName), true);  // true = append, false = overwrite
            bw = new BufferedWriter(fw);
            bw.write(L_DateTime);
            bw.newLine();
            bw.flush();
        } catch (IOException ioe) {
            //ioe.printStackTrace();
            System.out.println("LoggingHandler/WriteLogFile/Erp01: " + ioe);
        } finally {                       // always close the file
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException ioe2) {
                    // just ignore it
                }
            }
        }
    }
    
    
    
    /**
     * Close the Log file
     */
    public void CloseLogfile(){
       
        
        
        
        
    }    
    
}
