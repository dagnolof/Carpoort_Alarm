/*
 * By implementing SerialReader in his own class, we can use local variables to keep track
 * of the reveived data. Else we had to user Glabal variables. Once the JframeRs232TestMain main frame class
 * creat's an instance of the SerialReader class, the private variables will always exist, even when more than 
 * one serial portevent is triggered.
 */
package rs232test;

//import gnu.io.SerialPortEvent;
//import gnu.io.SerialPortEventListener;
//import com.fazecast.jSerialComm.*;
import com.fazecast.jSerialComm.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author fdag0
 */
public class SerialReader_EDR implements SerialPortDataListener {
    // Local private variables for SerialReader class
    @Override
    public int getListeningEvents() { return SerialPort.LISTENING_EVENT_DATA_RECEIVED; }
   
    private SerialPort In;
    //private byte[] L_SerialReaderBuffer;
    private byte[] delimitedMessage;
    //private int L_Data, L_Len = 0;
    String S_Rx_Buffer ="";
    private JframeRs232TestMain MainQui;     // Reference to JframeRs232TestMain.java Main Qui
    Timer T_RxComplete;
    //boolean L_PartlyRxDataFlag = false;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();

    // Constructor of SerialReader Class
    public SerialReader_EDR(SerialPort in, JframeRs232TestMain L_MainQui) {   // Reference to JframeRs232TestMain.java Main Qui
        this.In = in;
        MainQui = L_MainQui;   // By using MainQui. in this java file, we can use all methodes of the Mainqui

        // Define an instance of the RxComplete Timer
        T_RxComplete = new Timer();
    }

    @Override
    public void serialEvent(SerialPortEvent event) {
        if (S_Rx_Buffer.length() == 0) {
            //If No data is received yet,  we start an overall Timer. The RxHandler() will treat the received message.
            //The timer length is set from 500ms afther we have read an incomming SMS message.
            T_RxComplete.schedule(new RxHandler(), 850);
        }

        delimitedMessage = event.getReceivedData();
        delimitedMessage = RemoveCrLf(delimitedMessage);
       
        // Convert delimitedMessage Byte Array into string S_delimitedMessage
        // Specify the convertion Format UTF-8
        String S_delimitedMessage ="";
        try {
            S_delimitedMessage = new String(delimitedMessage, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(SerialReader_EDR.class.getName()).log(Level.SEVERE, null, ex);
        }

/* Test code to find problem in V02, String methode Contains NOT working
        System.out.println("Stringlength S_delimitedMessage: " +  S_delimitedMessage.length());  */
        S_Rx_Buffer = S_Rx_Buffer + S_delimitedMessage;
     //   System.out.println("Stringlength S_Rx_Buffer: " +  S_Rx_Buffer.length());   

        //String L_Time = genericCode.GetTimeString();
        //MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "SerialEvent RX: " + S_Rx_Buffer);
   
    }
    
    
    class RxHandler extends TimerTask {
        private String RxString = "";
        public synchronized void run() {
           
            //Copy the Received RS232 Message intp the MainQui.rxStructure
            //6-Dec-2018
            //We have a case where we receive a blank RS232 message, probably due to a RS232 message on a size limit.
            //We add a protection that we only update MainQui.rxStructure if the RxDataFlag is False. Being false it means
            //that de modemhandler treated the previous RS232 message.
            ////////////////////////////////////////////////////////////////////
            //8-Dec-2018
            //We have a verry verry strange behaviour of the code regarding the received RS232 data being placed in 
            //L_SerialReaderBuffer in the serialEvent class, and afterwards being copied into
            //MainQui.rxStructure.CopyRxBuffer(L_SerialReaderBuffer); in the Timertask Class
            //
            //After program startup, only the first received reply is copied like it should. First in L_SerialReaderBuffer
            //in the event handler, and after 850ms timeout the L_SerialReaderBuffer is copied into MainQui.rxStructure...
            //
            //the reply received on the second command is handled verry verry strange.
            //In the eventhandler the received bytes are stored in L_SerialReaderBuffer AND ALSO in MainQui.rxStructure... !!!!!!!
            //How can this be, this is what i see placing watch breakpoints, and also we discovered this problem after 
            //an error on the reply of the AT+CMGR=1 command, to read out the received SMS contents.
            //Normaly the reply should be "RX: +CMGR: "REC UNREAD","+32493408998",,"18/09/29...."
            //But we see sometimes        "RX: \r\nMGR: "REC UNREAD","+32493408998",,"18/09/29..."
            //Or                          "RX: MGR: "REC UNREAD","+32493408998",,"18/09/29..."
            //
            //The first characters of the reply are overwritten. 
            //Therefore we started looking in to this behaviour and found this malfunction.
            //
            //To solve this we replaced the MainQui.rxStructure.L_Buffer with MainQui.rxStructure.L_RxString
            //Meaning that in Timertask Class we convert S_Rx_Buffer into a RxString. Is is this RxString that we 
            //copy into the MainQui.rxStructure.  After this change the behaviour was gone !!!!!!!!!
            //
            //24-Sep-2019
            //Implementation on Raspberry-PI4
            //It might be a little different than descriped here above has implemeted on W10
            ////////////////////////////////////////////////////////////////////            
            if (!(MainQui.rxStructure.GetRxDataFlag())) {
                //L_SerialReaderBuffer = RemoveCrLf(L_SerialReaderBuffer);

                String L_Time = genericCode.GetTimeString();
                //MainQui.WriteInLogfile(L_Time + "SerialReader RX: " + (new String(L_SerialReaderBuffer, 0, L_Len)) + MainQui.Z_Nextline);
               // MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "RxHandler-TimerTask RX: " + S_Rx_Buffer);

                RxString = S_Rx_Buffer;
                RxString = RxString.trim();
                MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "RxHandler-TimerTask L128 RxString : " + RxString);
           //     MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "RxHandler-TimerTask L127 Lenght RxString : " + RxString.length());
                
                // A reply on a send command is completely received 
                // Copy the received RS232 in the RxTxRs232Structure array
                MainQui.rxStructure.CopyRxString(RxString);

                // Clear S_Rx_Buffer
                // public void serialEvent(SerialPortEvent event) here we check on the string length to deside if a nex msg is received.
                S_Rx_Buffer = "";

              //  MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "RxHandler-TimerTask L127 Length RxString : " + RxString.length());
                
                if (RxString.contains("OK")) {
                    MainQui.rxStructure.ChangeRxOKFlag(true);
//                    L_Time = genericCode.GetTimeString();
 //                   MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "RxHandler-TimerTask, RxOKFlag is set");
                }

                // Set the RxDataFlag
                MainQui.rxStructure.ChangeRxDataFlag(true);
               
                /* Test code to find problem in V02, String methode Contains NOT working               
                if (MainQui.rxStructure.GetRxDataFlag()) {
                    L_Time = genericCode.GetTimeString();
                    MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "RxHandler-TimerTask, RxDataFlag is set");
                }else {
                   L_Time = genericCode.GetTimeString();
                   MainQui.Write_In_Logfile(L_Time, "SerialReader_EDR.java", "", "", "RxHandler-TimerTask, RxDataFlag is NOT set");
                }  */                
            }
        }

    }
        


   
    
    private synchronized byte[] RemoveCrLf(byte[] L_In_Buffer) {
        // We return a Byte Array were the Cr/LF characters are not present anymore.
        // Make shure that the Array LEngth returned is equal to the ammount of characters in the return String. 
        // Else the string manipulation further in the program will fail.
        byte[] Temp_Buffer = new byte[L_In_Buffer.length];
        int L_Valid_Char_Counter = 0;

        for (int i = 0; i < L_In_Buffer.length; i++) {
            if ((L_In_Buffer[i] != '\n') && (L_In_Buffer[i] != '\r')) {
                Temp_Buffer[L_Valid_Char_Counter] = L_In_Buffer[i];
                L_Valid_Char_Counter++;
            }

        }

        // Define Result_Buffer with size of the L_Valid_Char_Counter
        byte[] Result_Buffer = new byte[L_Valid_Char_Counter];

        // Copy only the Valid characters into the result_Buffer
        // The for Loop is the manual array Copy
      /*  for (int i = 0; i < L_Valid_Char_Counter; i++) {
            Result_Buffer[i] = Temp_Buffer[i];
        }*/

        // This stament is the System Array Copy, does the sae thing has the Manual Array Copy with the For loop
        System.arraycopy(Temp_Buffer, 0, Result_Buffer, 0, L_Valid_Char_Counter); 
        
        return Result_Buffer;
    }
}
  