/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs232test;

import com.mysql.cj.util.StringUtils;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Database_sensormonitor {
    
    // Private Variables
    private JframeRs232TestMain MainQui;  // Reference to JframeRs232TestMain.java Main Qui
    // DB Logon 
    // Database sensormonitor located on same raspberry pi where this java application is running
    private static final String S_Mysql_Driver = "com.mysql.jdbc.Driver";
    private static final String S_Connect = "jdbc:mysql://localhost:3306/sensormonitor";
    private static final String S_Userid = "root";
    private static final String S_Password = "Msqld3agf2223";
    // Connection 
    //private Connection DB_Connect = null;
    //private Statement DB_Statement;
    //private ResultSet DB_Resultset1;
    public Connection DB_Connect = null;
    public Statement DB_Statement;
    public ResultSet DB_Resultset1;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    
    public Database_sensormonitor(JframeRs232TestMain L_MainQui){
        this.MainQui = L_MainQui; 
    }
    
    
    public void DatabaseConnect() {
        //methode that connects to the Mysql FuelMonitor Database
        try {
          //DB_Connect = DriverManager.getConnection(S_Connect + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC" + "&useSSL=false", S_Userid, S_Password);
          //26/nov/2018 
          //...serverTimezone=UTC"
          //Een sensor time occurence wordt in mysql database aangegeven als 1 uur minder !!!!
          //Dit is opgelost door ...serverTimezone=CET   op CET te plaatsen.
          //Ik weet niet of dit een correte oplossing is, maar het werkt wel.
          //Deze verandering onthouden voor later als het winteruur terug wordt aangepast naar zomeruur.
            DB_Connect = DriverManager.getConnection(S_Connect + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=true&serverTimezone=CET" + "&useSSL=false", S_Userid, S_Password);
            String L_Time = genericCode.GetTimeString();
            //MainQui.WriteInLogfile(L_Time + "Connection to Fuelmonitor Database OK" + MainQui.Z_Nextline);
            MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Connection to sensormonitor Database OK");
        } catch (Exception ex) {
            System.out.println("Error01: " + ex);
            String L_Time = genericCode.GetTimeString();
            MainQui.Write_In_Logfile(L_Time, "Database.java", "", "", "Connection to sensormonitor Database NOK");
        } finally {
        }
    }
}
