/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs232test;

//import gnu.io.CommPortIdentifier;
//import gnu.io.PortInUseException;
//import gnu.io.SerialPort;
//import gnu.io.UnsupportedCommOperationException;
//import com.fazecast.jSerialComm.*;
import com.fazecast.jSerialComm.*;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
//import gnu.io.SerialPortEventListener; 
//import gnu.io.SerialPortEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.TooManyListenersException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultCaret;


/**
 *
 * @author fdag0
 */
public class JframeRs232TestMain extends javax.swing.JFrame {

    /**
     * Creates new form JframeRs232TestMain
     */
    
    // Püblic variables for JframeRs232TestMain Class
    static final String Z_Nextline = "\n";
    SerialPort Z_PortId = null;
//    Enumeration Z_Comport;
    SerialPort Z_RS232_Port = null;
    OutputStream Z_RS232_Output;
    InputStream R_RS232_Input;
    BufferedReader R_RS232_Buffered_Reader_Input;
    JframeRs232TestMain Z_MainQui_Reference = this;
    //SmsHandler smsHandler;
    //TodoHandler todoHandler;
    //ModemHandler modemHandler;
    
    // Create an instance of the RxTxRs232Structure
    // In the rxStructure the received RS232 command will be copied for further treatment
    RxTxRs232Structure rxStructure = new RxTxRs232Structure(Z_MainQui_Reference);
    
    // Create an instance of the Systemstructure
    // This structure contains all system related data
    SystemStructure systemStructure = new SystemStructure();
    
    //Create an instance of the Todostructure
    // This structure contains all Todo related data
    TodoStructure todoStructure = new TodoStructure();
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // Define R_Datastructure of the mode M_DataStructure 
    // In the R_Datastructure array, we have one array entry per userid
    // An instance of the Datastructue is created in the database.java file.
    // We define R_Datastructure here so everyone with link to this MainQui, Z_MainQui_Reference can use R_Datastructure
    M_DataStructure[] R_Datastructure;
    /*
    Datastructure description 
    -------------------------
    R_Datastructure[x]      One array Entry Per Userid    Contents is of the Mode M_DataStructure
    
    M_DataStructure   String D_User_Id;
                      String D_User_Name;
                      int D_Nbr_Of_Smartboxs;
                      M_SmartboxStructure[] D_SmartboxData;   One Array Entry Per Smartboxid    Contents is of the Mode M_SmartboxStructure
    
    M_SmartboxStructure   int D_Smartbox_id;
                          String D_Gsm_Nbr;
                          int D_Nbr_Of_Sondes;
    */
    
    // Create an instance of the modem handler
    ModemHandler modemHandler = new ModemHandler(Z_MainQui_Reference);
    //Create an instance of the sms handler
    SmsHandler smsHandler = new SmsHandler(Z_MainQui_Reference);
    // Create an instance of the Todohandler
    TodoHandler todoHandler = new TodoHandler(Z_MainQui_Reference);
    // Create an instance of the LoggingHandler
    LoggingHandler loggingHandler = new LoggingHandler(Z_MainQui_Reference);
   
            
    public JframeRs232TestMain() {
        initComponents();
        
        // Make shure that scrolling in textarea is automatically set at the bottom.
        DefaultCaret caret = (DefaultCaret)this.jTextAreaLogfile.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        
        //Set background color of Modemstate indicator on RED
        this.jButtonModemStateIndicator.setBackground(Color.red);
        
        //Set background color of Database Parced indicator on RED
        this.jButtonDatabaseParcedIndicator.setBackground(Color.red);
   
        //Create Log Files sirectory
        this.loggingHandler.Create_Logfile_Directory();
        
        String Z_Test = "test string to logfile";
        this.loggingHandler.Write_Logfile(Z_Test);
        // Create an instance of the modem handler
        //ModemHandler modemHandler = new ModemHandler(Z_MainQui_Reference);
    
        // Create an instance of the SmsHandler
        //SmsHandler smsHandler = new SmsHandler(Z_MainQui_Reference);
        
        // Create an instance of the Todohandler
        //TodoHandler todoHandler = new TodoHandler(Z_MainQui_Reference);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabelModemState = new javax.swing.JLabel();
        jButtonModemStateIndicator = new javax.swing.JButton();
        jLabelDatabaseParcedFlag = new javax.swing.JLabel();
        jButtonDatabaseParcedIndicator = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButtonComportSearch = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaLogfile = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jComboBoxComports = new javax.swing.JComboBox<>();
        jButtonConnectComport = new javax.swing.JButton();
        jButtonCloseComport = new javax.swing.JButton();
        jLabelCommandToTx = new javax.swing.JLabel();
        jTextFieldCommandToTx = new javax.swing.JTextField();
        jRb_Ctrl_Z = new javax.swing.JRadioButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuDatabaseOpenInterface = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("RS232 Test");

        jLabelModemState.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelModemState.setText("Modem State: ");

        jButtonModemStateIndicator.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonModemStateIndicatorActionPerformed(evt);
            }
        });

        jLabelDatabaseParcedFlag.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelDatabaseParcedFlag.setText("Database Parced:");

        jButtonDatabaseParcedIndicator.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDatabaseParcedIndicatorActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("V06");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(93, 93, 93)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelModemState)
                    .addComponent(jLabelDatabaseParcedFlag))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonModemStateIndicator, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonDatabaseParcedIndicator, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelModemState)
                    .addComponent(jButtonModemStateIndicator, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButtonDatabaseParcedIndicator, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelDatabaseParcedFlag))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(jLabel4))
        );

        jButtonComportSearch.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonComportSearch.setText("Com Port Search");
        jButtonComportSearch.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonComportSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonComportSearchActionPerformed(evt);
            }
        });

        jTextAreaLogfile.setEditable(false);
        jTextAreaLogfile.setColumns(20);
        jTextAreaLogfile.setRows(5);
        jTextAreaLogfile.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPane1.setViewportView(jTextAreaLogfile);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 255));
        jLabel3.setText("Log Fle");

        jComboBoxComports.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jButtonConnectComport.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonConnectComport.setText("Connect Com Port");
        jButtonConnectComport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonConnectComport.setEnabled(false);
        jButtonConnectComport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConnectComportActionPerformed(evt);
            }
        });

        jButtonCloseComport.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCloseComport.setText("CLose Com Port");
        jButtonCloseComport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonCloseComport.setEnabled(false);
        jButtonCloseComport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCloseComportActionPerformed(evt);
            }
        });

        jLabelCommandToTx.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelCommandToTx.setText("Command To TX :");

        jTextFieldCommandToTx.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCommandToTx.setEnabled(false);
        jTextFieldCommandToTx.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldCommandToTxKeyPressed(evt);
            }
        });

        jRb_Ctrl_Z.setText("Send CTRL/Z");

        jMenuDatabaseOpenInterface.setText("Database");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("Open Interface");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenuDatabaseOpenInterface.add(jMenuItem1);

        jMenuBar1.add(jMenuDatabaseOpenInterface);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabelCommandToTx)
                                        .addGap(18, 18, 18)
                                        .addComponent(jTextFieldCommandToTx))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jButtonComportSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(55, 55, 55)
                                        .addComponent(jComboBoxComports, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(49, 49, 49)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButtonConnectComport, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButtonCloseComport, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jRb_Ctrl_Z))))
                        .addGap(0, 7, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonComportSearch)
                    .addComponent(jComboBoxComports, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonConnectComport)
                    .addComponent(jButtonCloseComport))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCommandToTx)
                    .addComponent(jTextFieldCommandToTx, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRb_Ctrl_Z))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        setSize(new java.awt.Dimension(691, 624));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonComportSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonComportSearchActionPerformed
      
        Z_PortId = SerialPort.getCommPort("ttyUSB0");
        
        jComboBoxComports.removeAllItems();   
        jComboBoxComports.addItem(Z_PortId.getSystemPortName());    
        
        // Add Log file entry
        this.jTextAreaLogfile.append("Comport Search executed   OK" + this.Z_Nextline);
              
             
        // Comport search executed, check if com ports where found
        // If comports found, we enable the button open comport
        if (this.jComboBoxComports.getItemCount() != 0){
            // Comports where found.
            // Enable Button to open the comport
            this.jButtonConnectComport.setEnabled(true);
           
            // Add log file entry wit the number of comports found
             this.jTextAreaLogfile.append("Number of comports Found : " + String.valueOf(this.jComboBoxComports.getItemCount()) + this.Z_Nextline);
        }   
    }//GEN-LAST:event_jButtonComportSearchActionPerformed

    
    
    private void jButtonConnectComportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConnectComportActionPerformed
        // Serial Port Found.
        // Now we can open the found port
       if (Z_PortId.openPort()) {
           this.jTextAreaLogfile.append("Comport Open    OK" + this.Z_Nextline); 
       
           // Set Comunication Parameters
           //Z_PortId.setComPortParameters(9600, 8, 1, 0);
           Z_PortId.setComPortParameters(115200, 8, 1, 0);
           this.jTextAreaLogfile.append("Communication Parameters set" + this.Z_Nextline); 
       
           // Enable Textentry command To Tx
           this.jTextFieldCommandToTx.setEnabled(true);
       
           //this.Z_PortId.addDataListener(new SerialReader_EDA(this.Z_PortId, Z_MainQui_Reference));
           this.Z_PortId.addDataListener(new SerialReader_EDR(this.Z_PortId, Z_MainQui_Reference));
           //this.Z_PortId.addDataListener(new SerialReader_MEDR(this.Z_PortId, Z_MainQui_Reference));
           
           // At this point the comport is active, we can start the Modem Handler
           this.modemHandler.ModemHandlerStart();
                        
           // Enable Button to close the comport
           this.jButtonCloseComport.setEnabled(true);
       
       }else {
           this.jTextAreaLogfile.append("Comport Open Failed" + this.Z_Nextline); 
        } 
        
       
        
/*        try {
            this.Z_RS232_Port = (SerialPort) this.Z_PortId.open("RXTX-Test", 5000);

            this.jTextAreaLogfile.append("Comport : " + this.Z_PortId.getSystemPortName() + " Is open" + this.Z_Nextline);

            // Enable Button to close the comport
            this.jButtonCloseComport.setEnabled(true);

            // Set communication parameters on the RS232 Port
            try {
                this.Z_RS232_Port.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
                this.Z_RS232_Port.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_IN);
                this.Z_RS232_Port.setFlowControlMode(SerialPort.FLOWCONTROL_RTSCTS_OUT);

                this.jTextAreaLogfile.append("Comport Parameters set  " + this.Z_Nextline);

                try {
                    this.R_RS232_Input = this.Z_RS232_Port.getInputStream();
                    this.R_RS232_Buffered_Reader_Input = new BufferedReader(new InputStreamReader(this.R_RS232_Input));
                    this.Z_RS232_Output = this.Z_RS232_Port.getOutputStream();

                    try {
                        // Create an instance of the SerialReader class that is located in another class.
                        // The reference to the MainQui claéss will be passed on with parameter Z_MainQui_Reference.
                        // Via this reference, the code in the SerialReader Class, can access all methodes of this. Class.
                        this.Z_RS232_Port.addEventListener(new SerialReader(this.R_RS232_Input, Z_MainQui_Reference));

                        this.Z_RS232_Port.notifyOnDataAvailable(true);
                        this.jTextAreaLogfile.append("Comport Eventlistener set  " + this.Z_Nextline);

                        // Enable Textentry command To Tx
                        this.jTextFieldCommandToTx.setEnabled(true);

                        // At this point the comport is active, we can start the Modem Handler
                        //modemHandler.ModemHandlerStart();
                        this.modemHandler.ModemHandlerStart();
                        //String todahandler_Z_State = this.todoHandler.Get_Z_State();
                    } catch (TooManyListenersException ex) {
                        Logger.getLogger(JframeRs232TestMain.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (IOException ex) {
                    System.err.println(ex.getMessage());
                    close();
                }

            } catch (UnsupportedCommOperationException ex) {
                System.err.println(ex.getMessage());
                close();
            }

        } catch (PortInUseException ex) {
            JOptionPane.showMessageDialog(null, "Comport Already in Use");
        }  */
    }//GEN-LAST:event_jButtonConnectComportActionPerformed

    
    
    private void jButtonCloseComportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCloseComportActionPerformed
        // Close the RS232 Port
        Z_PortId.removeDataListener();
        Z_PortId.closePort();
        this.jButtonCloseComport.setEnabled(false);
    }//GEN-LAST:event_jButtonCloseComportActionPerformed

    
    private void jTextFieldCommandToTxKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCommandToTxKeyPressed
        // TODO add your handling code here:
        char CtrlZ = 0x1A;
        String L_Command;
        
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (this.jRb_Ctrl_Z.isSelected()) {
                L_Command = Z_MainQui_Reference.jTextFieldCommandToTx.getText() + CtrlZ;
            }else {
               L_Command = Z_MainQui_Reference.jTextFieldCommandToTx.getText(); 
            }
            TransmitModemCommand(L_Command);
        }
    }//GEN-LAST:event_jTextFieldCommandToTxKeyPressed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        JframeDatabase Jframedatabase = new JframeDatabase(Z_MainQui_Reference);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    
    private void jButtonModemStateIndicatorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonModemStateIndicatorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonModemStateIndicatorActionPerformed

    private void jButtonDatabaseParcedIndicatorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDatabaseParcedIndicatorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonDatabaseParcedIndicatorActionPerformed
    
    
    // **************************
    // Write My own methodes here
    // **************************
/*    public void close() {
        //ModemHandler modemHandler;
        
/*        if (this.Z_RS232_Port != null) {
            // Add Log File entry
            this.jTextAreaLogfile.append("Comport : " + this.Z_PortId.getName() + " Is closed" + this.Z_Nextline);
            
            this.Z_RS232_Port.removeEventListener();
            this.Z_RS232_Port.close();
        }
        
        // Switch off the Mainlooptimer in the modemhandler
        modemHandler.ModemHandlerClose();*/
//    }

    
/*    public  void WriteInLogfile(String Line){
        this.jTextAreaLogfile.append(Line);
    }*/
    
    
    /**
     * Store a logging entry.
     * On the screen, and in a file
     * @param DateTime
     * @param JavaFile
     * @param State
     * @param ErrorPoint
     * @param Description 
     */
    public  void Write_In_Logfile(String DateTime, String JavaFile, String State, String ErrorPoint, String Description){
        String L_Log_Entry = DateTime.trim() + "," + JavaFile + "," + State + "," + ErrorPoint + "," +Description;
        this.jTextAreaLogfile.append(L_Log_Entry + this.Z_Nextline);
        this.loggingHandler.Write_Logfile(L_Log_Entry);
    }
    
    
    public void TransmitModemCommand(String L_Command) {
    //    byte[] L_Command_Array = L_Command.getBytes();
    byte[] L_Command_Array; 
   //     try {
            // Enter Key has been pressed in the Textfield
            // String is send to Wavecom Supreme modem, modem accepts an AT command if it is terminated with a Carriage Return "\r"
             L_Command = L_Command + "\r";
             L_Command_Array = L_Command.getBytes();
             Integer  L_Command_Length = L_Command.length() + 1;
             
             Z_PortId.writeBytes(L_Command_Array, L_Command_Length);
            // Set the Tx in progress Flag
            //this.rxStructure.SetTxProgressFlag(true);
            
            // Add Log File Entry with command Transmited
            //WriteInLogfile("TX: " + L_Command + this.Z_Nextline);
            String L_Time = genericCode.GetTimeString();
            Write_In_Logfile(L_Time, "JframeRs232TestMain.java", "", "", "TX: " + L_Command);
    //    } catch (IOException ex) {
    //        System.err.println(ex.toString());
    //    }
    }

    
    public void HandleModemState(){
    if (this.systemStructure.GetModemConnectedFlag()) this.jButtonModemStateIndicator.setBackground(Color.green);
    else this.jButtonModemStateIndicator.setBackground(Color.red);
    
    //26-Nov-2018
    //We set the database parced flag, the database will not be read into the java application anymore.
    //This makes it way to complicated to mantain the user data, this task can better be handled by the web application.
    if (this.systemStructure.GetDatabaseParcedFlag()) this.jButtonDatabaseParcedIndicator.setBackground(Color.green);
    else this.jButtonDatabaseParcedIndicator.setBackground(Color.red);
    }
    
    
    public void HandleDatabaseParcedState(){
    if (this.systemStructure.GetDatabaseParcedFlag()) this.jButtonDatabaseParcedIndicator.setBackground(Color.green);
    else this.jButtonDatabaseParcedIndicator.setBackground(Color.red);
    }
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       
        //</editor-fold
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JframeRs232TestMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCloseComport;
    private javax.swing.JButton jButtonComportSearch;
    private javax.swing.JButton jButtonConnectComport;
    private javax.swing.JButton jButtonDatabaseParcedIndicator;
    private javax.swing.JButton jButtonModemStateIndicator;
    private javax.swing.JComboBox<String> jComboBoxComports;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelCommandToTx;
    private javax.swing.JLabel jLabelDatabaseParcedFlag;
    private javax.swing.JLabel jLabelModemState;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuDatabaseOpenInterface;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRb_Ctrl_Z;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaLogfile;
    private javax.swing.JTextField jTextFieldCommandToTx;
    // End of variables declaration//GEN-END:variables
}
