/*
 * The Todo Handler will san the mysql Table t_todo.
 * The handler will orchestrate the subsequent actions.

  * The Todohandler will also create the contents of the Todo table based on the table t_smartbox_scan_times.
  * Every user with a smartbox has an entry in this table. There are 4 possible times 
  * that the user can define for scanning the Smartboxs. 
  * d_scan_time1,2,3 and 4.  If the scan time is not equal to 00:00:00 it means the scan time 
  * is active. For every active scan_time an entry in t_todo is created.

  * t_system, the boolean d_todo_change colomn will not b eimplimented, see note on 23/nov/2018
  * In the system Tabel, t_system, the boolean d_todo_change colomn, indicates if there is a 
  * change done in t_smartbox_scan_times. This flag will be set by the web application.
  * The Todohandler has to check if this flag is set. In this case the t_todo has to be 
  * recreated to take into account scan_tile changes.

  * 23/Nov/2018
  * It is not a good idee to use t_system, the boolean d_todo_change colomn has an indication for a 
  * scan time change, because this colomn is common for all smartbox's. Meaning that the whole table, t_todo, 
  * has to be recalculated. It is a better pratice to impliment a change indicator on smartbox level, and even
  * add an immediate scan indicator, if the user wants an immedicate reading of this particular smartbox.
  * Add a colomn in t_smartbox_scan_times.d_immedate_action.

  * 26/Nov/2018
  * It is maybe easier to create and mantain the todo table, t_todo, via the web application. The web application
  * knows witch sensors are changed....
  * The task of the java application is to read and handle the sms actions according to the entry in the t_todo.
  * The only extra action for the java application is to find de Gsm  number  and the number of sensors connected
  * to the smartbox specified in the todo table. This data can be found in the t_smartboxs. 
  * This has NOT to be prefetched by the java application like we implemented it today. This makes it way to complicated 
  * to mantain the user data, this task can better be handled by the web application.
*/
package rs232test;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.sql.*;
import java.time.LocalTime;

/**
 *
 * @author fdag0
 */
public class TodoHandler {
    //Private variables of class SmsHandler
    private JframeRs232TestMain MainQui;     //// Reference to JframeRs232TestMain.java Main Qui

    //Timer Value
    private static final Integer Z_Mainloop_Timer = 250;                        //250ms timer value
  //  private static final Integer T_Wait_Execution_Timer_Counter_Value = 240;    //60s Timer, 4 250ms timer tics per sec, For 60s = 60 X4  = 240 Timer tics 
    private static final Integer T_Wait_Execution_Timer_Counter_Value = 20;     //5s Timer, 4 250ms timer tics per sec, For 5s = 5 X 4  = 20 Timer tics 
  //  private static final Integer T_Wait_Execution_Timer_Counter_Value = 40;     //10s Timer, 4 250ms timer tics per sec, For 10s = 10 X 4  = 40 Timer tics 
    
    //Variables for the TodoHandler Class
    private enum E_State {
        Ms_Start, Ms_Check_Table_Todo, Ms_Treat_Todo_Entry, Ms_Check_Modem_And_Database_State, Ms_Check_Execution_Time, Ms_Check_Actions, 
        Ms_Check_Modem_State, Ms_Done;
    };
    private E_State Z_State, Z_State_Previous;
    private Timer timer;
    private Date DateTime = new Date();
    private Integer Z_T_Wait_Execution_Timer_Counter = 0;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // Constructor of SmsHandler Class
    public TodoHandler(JframeRs232TestMain L_MainQui) {   // L_MainQui is a reference to the calling MainQui
        this.MainQui = L_MainQui;                        // By using MainQui. in this java file, we can use all methodes of the Mainqui
        this.TodoHandlerStart();
    }

    /**
     * Cancel the Mainlooptimer
     */
    public void TodoHandlerClose() {
        timer.cancel();
    }
    
    
    /**
     * Cancel the Mainlooptimer
     */
    public String Get_Z_State() {
        return Z_State.toString();
    }
    
    

    /**
     * Start the TodoHandler by scheduling the timer that will trigger the
     * Mainloop
     */
    public void TodoHandlerStart() {
        // Initialise Z_State here. If we place this instruction afther the timer.schedule coinstruction.
        // We get NULL pointer execptions error on the use of this variable in the code !!!!!
        this.Z_State = E_State.Ms_Start;
        this.Z_State_Previous = E_State.Ms_Done;

        // Schedule the Mainloop Timer, Initial timeout is 2000ms, subsequent timeouts are 5000ms
        // We need the initial timeout of 2000ms to let the JframeRs232TestMain initialise.
        // Because once the Mainloop starts we will write a string into the MainQui.WriteInLogfile....
        // Without the initial timeout we get an exeption error in MainQui.WriteInLogfile...
        timer = new Timer();
        timer.schedule(new MainLoop(), 2000, Z_Mainloop_Timer);

    }

    class MainLoop extends TimerTask {
        //private byte[] L_Buffer = new byte[100];
        //private int ThreadPriority, ThreadMin, ThreadMax;
        //Date date = new Date();
        //Calendar calendar = Calendar.getInstance();
        //java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
        //java.sql.Time todoTime = new java.sql.Time(calendar.getTime().getTime());

        public synchronized void run() {
            String L_Time;
            
            if (Z_State.name() == null ? Z_State_Previous.name() != null : !Z_State.name().equals(Z_State_Previous.name())) {
                L_Time = genericCode.GetTimeString();
                //MainQui.WriteInLogfile(L_Time + "TodoHandler Z_State  " + Z_State.name() + MainQui.Z_Nextline);
                MainQui.Write_In_Logfile(L_Time, "TodoHandler.java", Z_State.name(), "", "");
            }
      
            Z_State_Previous = Z_State;

            switch (Z_State) {
                case Ms_Start:
                    //Do Startup Actions here
                    Z_T_Wait_Execution_Timer_Counter = 0;
                    
                    Z_State = E_State.Ms_Check_Modem_State;

                    break;

                case Ms_Check_Modem_State:
                    //Check if Modem is true
                    //Z_State = E_State.Ms_Sent_ATE0_Wait_OK;
                    if (MainQui.systemStructure.GetModemConnectedFlag()) {
                        //Set the entry_available_Flag in the todoStructure
                        //MainQui.todoStructure.ChangeEntryAvailableFlag(true); 
                        Z_State = E_State.Ms_Check_Actions;
                    }

                    break;
                    
                    
                case Ms_Check_Actions:
                    //Check if there are Immediate actions to execute.
                    //Check if t_smartbox_scan_times contains entrys where d_immediate_action is set ?
                    try {
                        //Create an instance of the Database.java class
                        Database database = new Database(MainQui);

                        //Connect to Fuelmonitor mysql database
                        database.DatabaseConnect();
                        
                        database.DB_Statement = database.DB_Connect.createStatement();

                        String Query = "select * from t_todo WHERE d_immediate_action=1 ORDER BY d_time";
                        database.DB_Resultset1 = database.DB_Statement.executeQuery(Query);

                        //If there is an entry found in Table Todo we treat it
                        if (database.DB_Resultset1.first()) {
                            String d_id = database.DB_Resultset1.getString("d_id");
                            String d_user_id = database.DB_Resultset1.getString("d_user_id");
                            String d_user_name = database.DB_Resultset1.getString("d_user_name");
                            String d_smartbox_id = database.DB_Resultset1.getString("d_smartbox_id");
                            Boolean d_immediate_action = database.DB_Resultset1.getBoolean("d_immediate_action");
                            //java.sql.Timestamp d_time = database.DB_Resultset1.getTimestamp("d_time");
                            java.sql.Time d_time = database.DB_Resultset1.getTime("d_time");
                            Query = "select * from t_smartboxs WHERE d_user_name = '" + d_user_name + "'" + " AND " + "d_smartbox_id=" + d_smartbox_id;
                            database.DB_Resultset1 = database.DB_Statement.executeQuery(Query);

                            if (database.DB_Resultset1.first()) {
                                String d_gsm_nr = database.DB_Resultset1.getString("d_gsm_nr");
                                String d_nbr_of_sondes = database.DB_Resultset1.getString("d_nbr_of_sondes");
                                Integer d_nbr_of_sondes_int = Integer.parseInt(d_nbr_of_sondes);

                                //Fill in todoStructure entry
                                MainQui.todoStructure.CreateTodoEntry_tankmonitor("Tank-Monitor", d_id, d_user_id, d_user_name, d_smartbox_id, d_gsm_nr, d_nbr_of_sondes_int, d_immediate_action, d_time, false);
                                MainQui.todoStructure.ChangeEntryAvailableFlag(true);
                                
                                L_Time = genericCode.GetTimeString();
                                //MainQui.WriteInLogfile(L_Time + "TodoHandler Z_State,  " + Z_State.name() + " Immediate Action Found   user_id: " + d_user_id + "  Smartbox-id: " + d_smartbox_id + MainQui.Z_Nextline);
                                MainQui.Write_In_Logfile(L_Time, "TodoHandler.java", Z_State.name(), "", "Immediate Action Found   user_id: " + d_user_id + "  Smartbox-id: " + d_smartbox_id);
                                Z_State = E_State.Ms_Treat_Todo_Entry;
                            }
                        } else {//There are no immediate actions.
                                L_Time = genericCode.GetTimeString();
                                MainQui.Write_In_Logfile(L_Time, "TodoHandler.java", Z_State.name(), "", "No Immediate todo actions Found");
                                
                                //Check is there are Gsm Sensor actions. This has nothing to do with tank-monitor.
                                //We use the GSM modem connected to tank-monitor application to send SMS in case of sensor that require this action.
                                if(Check_Gsm_Sensor_Actions()){
                                   MainQui.todoStructure.ChangeEntryAvailableFlag(true);
                                   Z_State = E_State.Ms_Treat_Todo_Entry;
                                } else {
                                    // There are gsm Actions found 
                                    Z_State = E_State.Ms_Check_Table_Todo;
                                }
                        }
                      
                        //Close the database
                        database.DB_Connect.close();
                        database.DB_Statement.close();
                        database.DB_Resultset1.close();

                    } catch (Exception ex) {
                        System.out.println("Error: " + ex);
                    } finally {
                    }
                    
                    break;
                    //Z_State = E_State.Ms_Check_Table_Todo;
                       
                    
                    
                case Ms_Check_Table_Todo:
 
                    try {
                        // Create an instance of the Database.java class
                        Database database = new Database(MainQui);

                        //Connect to Fuelmonitor mysql database
                        database.DatabaseConnect();

                        //Query table t_todo
                        //Define the Sql Statement
                        database.DB_Statement = database.DB_Connect.createStatement();

                        String Query = "select * from t_todo WHERE d_done=0 ORDER BY d_time";
                        database.DB_Resultset1 = database.DB_Statement.executeQuery(Query);

                        //If there is an entry found in Table Todo we treat it
                        if (database.DB_Resultset1.first()) {
                            String d_id = database.DB_Resultset1.getString("d_id");
                            String d_user_id = database.DB_Resultset1.getString("d_user_id");
                            String d_user_name = database.DB_Resultset1.getString("d_user_name");
                            String d_smartbox_id = database.DB_Resultset1.getString("d_smartbox_id");
                            Boolean d_immediate_action = database.DB_Resultset1.getBoolean("d_immediate_action");
                            java.sql.Time d_time = database.DB_Resultset1.getTime("d_time");
      
                            //Query t_smartboxs with the d_user_id and d_smartbox_id to find the d_gsm_nbr and d_nbr_of_sondes 
                            //belonging to this t_todo entry.
                            Query = "select * from t_smartboxs WHERE d_user_name = '" + d_user_name + "'" + " AND " + "d_smartbox_id=" + d_smartbox_id;
                            database.DB_Resultset1 = database.DB_Statement.executeQuery(Query);
                            
                            if (database.DB_Resultset1.first()) {
                                String d_gsm_nr = database.DB_Resultset1.getString("d_gsm_nr");
                                String d_nbr_of_sondes = database.DB_Resultset1.getString("d_nbr_of_sondes");
                                Integer d_nbr_of_sondes_int = Integer.parseInt(d_nbr_of_sondes);
                          
                                L_Time = genericCode.GetTimeString();
                                //MainQui.WriteInLogfile(L_Time + "TodoHandler Z_State,  " + Z_State.name() + " Todo Action Found  Due Time:" + d_time + "  Username: " + d_user_name + "  Smartbox-id: " + d_smartbox_id + MainQui.Z_Nextline);
                                MainQui.Write_In_Logfile(L_Time, "TodoHandler.java", Z_State.name(), "", "Todo Action Found  Due Time:" + d_time + "  Username: " + d_user_name + "  Smartbox-id: " + d_smartbox_id);
                                
                                //Fill in todoStructure entry, leave the entry_available_Flag on false for now.
                                MainQui.todoStructure.CreateTodoEntry_tankmonitor("Tank-Monitor", d_id, d_user_id, d_user_name, d_smartbox_id, d_gsm_nr, d_nbr_of_sondes_int, d_immediate_action, d_time, false);
                                Z_State = E_State.Ms_Check_Execution_Time;
                            }
                        } else {
                            //All entrys in t_todo are treated, all todo actions are done.
                            //Reset for all entrys in t_todo.d_done = 0
                            L_Time = genericCode.GetTimeString();
                            //MainQui.WriteInLogfile(L_Time + "TodoHandler Z_State  " + Z_State.name() + "  All todo actions in t_todo are DONE" + MainQui.Z_Nextline);
                            MainQui.Write_In_Logfile(L_Time, "TodoHandler.java", Z_State.name(), "", "All todo actions in t_todo are DONE");

                            try {
                                // Create an instance of the Database.java class
                               // Database database = new Database(MainQui);

                                //Connect to Fuelmonitor mysql database
                                //database.DatabaseConnect();

                                //Query table t_todo
                                //Define the Sql Statement
                                database.DB_Statement = database.DB_Connect.createStatement();

                                String d_id = MainQui.todoStructure.GetId();
                                String Query1 = "UPDATE t_todo SET d_done=0 WHERE d_done=1";
                                //database.DB_Resultset1 = database.DB_Statement.executeQuery(Query);
                                database.DB_Statement.executeUpdate(Query1);

                                //Close the database
                                database.DB_Connect.close();
                                database.DB_Statement.close();

                                L_Time = genericCode.GetTimeString();
                                //MainQui.WriteInLogfile(L_Time + "TodoHandler Z_State,  " + Z_State.name() + " d_done indicators are reset for all t_todo entrys" + MainQui.Z_Nextline);
                                MainQui.Write_In_Logfile(L_Time, "TodoHandler.java", Z_State.name(), "", "d_done indicators are reset for all t_todo entrys");
                                
                                Z_State = E_State.Ms_Done;
                            } catch (Exception ex) {
                                System.out.println("Error: " + ex);
                            } finally {
                            }                                
                        }
                      
                        //Close the database
                        database.DB_Connect.close();
                        database.DB_Statement.close();
                        database.DB_Resultset1.close();

                    } catch (Exception ex) {
                        System.out.println("Error: " + ex);
                    } finally {
                    }
                    
                    break;
                    

                case Ms_Check_Execution_Time:
                    //If the actual time is > than the todo table time we execute the Todo Entry
                    //Get the actual time. Remark that we have to define the calendar instance here.
                    Calendar calendar = Calendar.getInstance();
                    
                    //Gettime is is time at creation of the calendar instance.
                    java.sql.Time actualTime = new java.sql.Time(calendar.getTime().getTime());
                    
                    //We had a lot of problems getting the time readings out of the mysql database into java wright.
                    //In mysql d_time is defined has a TIME datatype, however the date part set to 1-Jan-1970 is still present into the TIME datatype.
                    //In Java, we define the time variable has a java.sql.Time object type, also here the date is part of the TIME datatype, and 
                    //worse it is taken into account when comparing time variables. Resulting in errors because the mysql TIME is set to 1-Jan-1970 !!!!!
                    //To overcome this i found the best practise, to convert both TIME objects to LocalTime Objects. Comparing the LocalTime objects 
                    //resulted in correct behaviour.
                    LocalTime localTime = actualTime.toLocalTime();
                    java.sql.Time todoTime;
                    
                    //Check if we have the System Todo Entry, if so se set the ececution time on "00:05:00"
                    //Because if we leave the execution time on 23:55:00 all d_done flags in t_todo will be reset.
                    //This will trigger the sending of sms again for all t_todo entrys because the actualtime between 23:55:00 and 23:59:59
                    //is afther the todotime. Therefore we set the time on 5 minutes past midnight. In the next paragraaf of coding we check again
                    //if we have the system entry, if so we have to check if the localTime.ISBEFORE(localTodoTime)
                    String d_user_name = MainQui.todoStructure.GetUserName();
                    if (d_user_name.equals("system")) {
                        todoTime = Time.valueOf("00:05:00");
                    } else {
                        todoTime = MainQui.todoStructure.GetTime();
                    }
                    
                    LocalTime localTodoTime = todoTime.toLocalTime();
                    Boolean L_Time_Reached = false;

                    // 
                    if (d_user_name.equals("system")) {
                        if (localTime.isBefore(localTodoTime)) {
                            Z_State = E_State.Ms_Treat_Todo_Entry;
                            L_Time_Reached = true;
                        }
                    } else {
                        if (localTime.isAfter(localTodoTime)) {
                            MainQui.todoStructure.ChangeEntryAvailableFlag(true);
                            Z_State = E_State.Ms_Treat_Todo_Entry;
                            L_Time_Reached = true;
                        }
                    }

                    if (!(L_Time_Reached)){
                        //Here we are waiting for the todo entry to match the executione time. 
                        //If an immediate actions is iserted into t_todo, we will not detect it. Also if a todo action is inserted 
                        //with an execution time lower than the execution time of the actual entry, we will also not detect it.
                        //Therefore we zill jump out of this wit loop every minute to check if there are othre entrys in the todo table.
                        Z_T_Wait_Execution_Timer_Counter++;
                        
                        if (Z_T_Wait_Execution_Timer_Counter.equals(T_Wait_Execution_Timer_Counter_Value)){
                            Z_State = E_State.Ms_Check_Actions;
                            Z_T_Wait_Execution_Timer_Counter = 0;
                        }  
                    }

                    break;
                    
                    
                case Ms_Treat_Todo_Entry:
                    //Check if BusyFlag && EntryAvailableFlag are both false.
                    //If so, we consider the todo entry has been treated.
                    if (!(MainQui.todoStructure.GetBusyFlag()) && !(MainQui.todoStructure.GetEntryAvailableFlag())) {
                        //V04 16-Oct-2019
                        //Due to introduction of Gsm_Actions we check first fot witch application the todo entry was created, Tankmonitor or Gsm_Action application
                        String L_Application = MainQui.todoStructure.GetApplication();
                        
                        switch (L_Application) {
                            case "Tank-Monitor":
                                //Check if the t_todo action was due to an immediate actione.
                                if (MainQui.todoStructure.GetImmediateActionFlag()) {
                                    //Todo entry is due to an immediate action trigger. 
                                    //This is a one time action, delete this entry out of the t_todo
                                    //
                                    // 1-Oct-2019
                                    // We change the Behaviour, the user can set via the website  an immediate action on a smartbox.
                                    // After immediate action is completed we should not delete this action. 
                                    // Just set this t_todo entry on done, has in the else state. We will leave the Then state in case it might 
                                    // change again in the future
                                    try {
                                        // Create an instance of the Database.java class
                                        Database database = new Database(MainQui);

                                        //Connect to Fuelmonitor mysql database
                                        database.DatabaseConnect();

                                        //Query table t_todo
                                        //Define the Sql Statement
                                        database.DB_Statement = database.DB_Connect.createStatement();

                                        String d_id = MainQui.todoStructure.GetId();
                                        //String Query = "DELETE FROM t_todo WHERE d_id = '" + d_id + "' ";
                                        String Query = "UPDATE t_todo SET d_immediate_action = 0 WHERE d_id = '" + d_id + "' ";
                                        //database.DB_Resultset1 = database.DB_Statement.executeQuery(Query);
                                        database.DB_Statement.executeUpdate(Query);

                                        //Close the database
                                        database.DB_Connect.close();
                                        database.DB_Statement.close();
                                        //database.DB_Resultset1.close();

                                        Z_State = E_State.Ms_Done;
                                    } catch (Exception ex) {
                                        System.out.println("Error: " + ex);
                                    } finally {
                                    }
                                } else {
                                    //The todo entry has been treated set the d_done flag for this entry

                                    try {
                                        // Create an instance of the Database.java class
                                        Database database = new Database(MainQui);

                                        //Connect to Fuelmonitor mysql database
                                        database.DatabaseConnect();

                                        //Query table t_todo
                                        //Define the Sql Statement
                                        database.DB_Statement = database.DB_Connect.createStatement();

                                        String d_id = MainQui.todoStructure.GetId();
                                        String Query = "UPDATE t_todo SET d_done = 1 WHERE d_id = '" + d_id + "' ";
                                        //database.DB_Resultset1 = database.DB_Statement.executeQuery(Query);
                                        database.DB_Statement.executeUpdate(Query);

                                        //Close the database
                                        database.DB_Connect.close();
                                        database.DB_Statement.close();
                                        //database.DB_Resultset1.close();

                                        Z_State = E_State.Ms_Done;
                                    } catch (Exception ex) {
                                        System.out.println("Error: " + ex);
                                    } finally {
                                    }

                                }

                                break;

                            case "Gsm-Action":
                                try {
                                    // Create an instance of the Database.java class
                                    Database_sensormonitor db_sensormonitor = new Database_sensormonitor(MainQui);

                                    //Connect to Fuelmonitor mysql database
                                    db_sensormonitor.DatabaseConnect();

                                    //Query table t_todo
                                    //Define the Sql Statement
                                    db_sensormonitor.DB_Statement = db_sensormonitor.DB_Connect.createStatement();

                                    String d_id = MainQui.todoStructure.GetId();
                                    String Query = "UPDATE t_todo_sensors SET d_done = 1 WHERE d_id = '" + d_id + "' ";
                                    
                                    db_sensormonitor.DB_Statement.executeUpdate(Query);

                                    //Close the database
                                    db_sensormonitor.DB_Connect.close();
                                    db_sensormonitor.DB_Statement.close();

                                    Z_State = E_State.Ms_Done;
                                } catch (Exception ex) {
                                    System.out.println("Error: " + ex);
                                } finally {
                                }
                                
                                break;
                               
                        }

                    }

                    break;
                    
                    
                case Ms_Done:
                    //Todo Entry is treated, scan table t_todo for a new entry
                    Z_State = E_State.Ms_Check_Modem_State;
                    
                    break;
          
                    
            }
        }
        
        
        
        private boolean Check_Gsm_Sensor_Actions() {
            boolean L_Result = false;
            
            try {
                // Create an instance of the Database.java class
                Database_sensormonitor db_sensormonitor = new Database_sensormonitor(MainQui);

                //Connect to Fuelmonitor mysql database
                db_sensormonitor.DatabaseConnect();

                db_sensormonitor.DB_Statement = db_sensormonitor.DB_Connect.createStatement();

                String Query = "select * from t_todo_sensors WHERE d_done = 0 ORDER BY d_time";
                db_sensormonitor.DB_Resultset1 = db_sensormonitor.DB_Statement.executeQuery(Query);

                //If there is an entry found in Table Todo we treat it
                if (db_sensormonitor.DB_Resultset1.first()) {
                    String d_id = db_sensormonitor.DB_Resultset1.getString("d_id");
                    String d_unit_id = db_sensormonitor.DB_Resultset1.getString("d_unit_id");
                    String d_sensor_id = db_sensormonitor.DB_Resultset1.getString("d_sensor_id");
                    //java.sql.Timestamp d_time = database.DB_Resultset1.getTimestamp("d_time");
                    //java.sql.Time d_time = db_sensormonitor.DB_Resultset1.getTime("d_time");
                    Query = "select * from t_sensors WHERE d_unit_id = '" + d_unit_id + "'" + " AND " + "d_sensor_id=" + d_sensor_id;
                    db_sensormonitor.DB_Resultset1 = db_sensormonitor.DB_Statement.executeQuery(Query);

                    if (db_sensormonitor.DB_Resultset1.first()) {
                        String d_gsm_nr = db_sensormonitor.DB_Resultset1.getString("d_gsm_nr");
                        String d_alarm_text = db_sensormonitor.DB_Resultset1.getString("d_alarm_text");
                        //Fill in todoStructure entry
                        MainQui.todoStructure.CreateTodoEntry_gsm_actions("Gsm-Action", d_id, d_unit_id, d_sensor_id, d_gsm_nr, d_alarm_text, true);
                        //MainQui.todoStructure.ChangeEntryAvailableFlag(true);

                        String L_Time = genericCode.GetTimeString();
                        MainQui.Write_In_Logfile(L_Time, "TodoHandler.java Check_Gsm_Sensor_Actions()", Z_State.name(), "", "Gsm Action Found   unit_id: " + d_unit_id + "  Sensor-id: " + d_sensor_id);
                        L_Result = true;
                    }
                    else {
                        String L_Time = genericCode.GetTimeString();
                        MainQui.Write_In_Logfile(L_Time, "TodoHandler.java Check_Gsm_Sensor_Actions()", Z_State.name(), "", "No t_sensors data found for d_unit_id  " + d_unit_id + "  d_sensor-id: " + d_sensor_id);
                        L_Result = false;
                    }
                } else {//There are no Sensor Gsm Actions Found.
                    String L_Time = genericCode.GetTimeString();
                    MainQui.Write_In_Logfile(L_Time, "TodoHandler.java Check_Gsm_Sensor_Actions()", Z_State.name(), "", "No Sensor Gsm Actions Found");
                     
                    L_Result = false;
                }

                //Close the database
                db_sensormonitor.DB_Connect.close();
                db_sensormonitor.DB_Statement.close();
                db_sensormonitor.DB_Resultset1.close();
            } catch (Exception ex) {
                System.out.println("Error: " + ex);
            } finally {
            }
            
            if (L_Result) return true;
            else return false;

        }
    }
}
