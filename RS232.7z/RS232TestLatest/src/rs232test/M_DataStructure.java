/* This structure contains All info abount users and there connected smartboxes.
 * This structure is filled up at program startup. All data is retrieved ot of the Mysql database
 * located on the Vibit Server. 
 */
package rs232test;

/**
 *
 * @author fdag0
 */
public class M_DataStructure {
    /* Datasefinitions in the M_DataStructure Class */
    private String D_User_Id;
    private String D_User_Name;
    private int D_Nbr_Of_Smartboxs;
    private M_SmartboxStructure[] D_SmartboxData; 
    
    
    public M_DataStructure(String User_Id, String User_Name) {
      D_User_Id = User_Id;
      D_User_Name = User_Name;
    }

    /**
     * Update Nbr_Of_Smartboxes in the datastructure.
     * Since we know the number of smartboxs we can also create the correct array size to
     * hold info about the smartboxs.
     * @param Nbr_Of_Smartboxs
     */
    public synchronized void Set_Nbr_Of_Smartboxs(String Nbr_Of_Smartboxs){
       this.D_Nbr_Of_Smartboxs = Integer.parseInt(Nbr_Of_Smartboxs);
       
       D_SmartboxData = new M_SmartboxStructure[this.D_Nbr_Of_Smartboxs + 1];
    }
  
    
    /**
     * Update Nbr_Of_Smartboxes in the datastructure. Since we know the number
     * of smartboxs we can also create the correct array size to hold info about
     * the smartboxs.
     *
     * @param d_smartbox_id, d_gsm_nr
     */
    public synchronized void Set_Gsm_Nbr(String d_smartbox_id, String d_gsm_nr) {
        int I_d_smartbox_id = Integer.parseInt(d_smartbox_id);
        
        D_SmartboxData[I_d_smartbox_id] = new M_SmartboxStructure(d_smartbox_id, d_gsm_nr);
    }
    
    
    /**
     * Update Nbr_Of_Sondes in the datastructure. 
     * .
     *
     * @param d_smartbox_id, d_Nbr_Of_Sondes
     */
    public synchronized void Set_Nbr_Of_Sondes(Integer d_smartbox_id, String Nbr_Of_Sondes) {
        //int I_d_smartbox_id = Integer.parseInt(d_smartbox_id);
        
        D_SmartboxData[d_smartbox_id].Set_Nbr_Of_Sondes(Nbr_Of_Sondes);
    }
    
    
    /**
     * Return the Usrname to the caller
     * @return D_User_Name
     */
    public synchronized String Get_UserName(){
       return this.D_User_Name;
    }
    
    /**
     * Return the D_Nbr_Of_Smartboxs to the caller
     *
     * @return D_Nbr_Of_Smartboxs
     */
    public synchronized int Get_Nbr_Of_Smartboxs() {
        return this.D_Nbr_Of_Smartboxs;
    }
    
    
    /**
     * Get the Gsm_Nbr out of the M_Smartboxstructure
     * .
     *
     * @param d_smartbox_id
     */
    public synchronized String Get_Gsm_Nbr(Integer d_smartbox_id) {
        //int I_d_smartbox_id = Integer.parseInt(d_smartbox_id);
        
        return D_SmartboxData[d_smartbox_id].Get_Gsm_Nbr();
    }
    
    
    /**
     * Get the Gsm_Nbr out of the M_Smartboxstructure
     * .
     *
     * @param d_smartbox_id
     */
    public synchronized Integer Get_Nbr_Of_Sondes(Integer d_smartbox_id) {
        //int I_d_smartbox_id = Integer.parseInt(d_smartbox_id);
        
        return D_SmartboxData[d_smartbox_id].Get_Nbr_Of_Sondes();
    }
}
