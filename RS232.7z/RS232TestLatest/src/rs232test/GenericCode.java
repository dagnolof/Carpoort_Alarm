/*
 * In this class we write the code that is generic, and can be used in a lot of places
 * Also in other programs
 */
package rs232test;

import java.util.Calendar;

/**
 *
 * @author fdag0
 */
public class GenericCode {
    //Private Variables
    
    //Class connstructor
    public void GerericCode() {

    }
    
    /**
     * Return the actual time 
     * Fromat HH:MM:SS:HS
     * @return String representing the actual time
     */
    public String GetTimeString() {
        String L_TimeString, L_Leading_Zeros_Hours, L_Leading_Zeros_t_seconds;

        Calendar calendar = Calendar.getInstance();
        //DateTime = calendar.getTime();
        //MainQui.WriteInLogfile("Time " + DateTime + MainQui.Z_Nextline);

        Integer hours = calendar.get(calendar.HOUR_OF_DAY);
        Integer minutes = calendar.get(calendar.MINUTE);
        Integer seconds = calendar.get(calendar.SECOND);
        Integer t_seconds = calendar.get(calendar.MILLISECOND);
        //Integer year = calendar.get(calendar.YEAR);
        //Integer maand = calendar.get(calendar.MONTH);
        //Integer dag = calendar.get(calendar.DAY_OF_MONTH);

        if (hours < 10) {
            L_Leading_Zeros_Hours = "0";
        } else {
            L_Leading_Zeros_Hours = "";
        }
        
        if (t_seconds < 10) {
           L_Leading_Zeros_t_seconds = "00"; 
        } else if (t_seconds < 100) {
           L_Leading_Zeros_t_seconds = "0"; 
        } else L_Leading_Zeros_t_seconds = "";

        L_TimeString = L_Leading_Zeros_Hours + hours + ":" + minutes + ":" + seconds + ":" + L_Leading_Zeros_t_seconds + t_seconds + "  ";
        return L_TimeString;
    }
    
    
    public Integer Count_Occurences_In_String(String Rx_String, String Occurence_Patters) {
        //Return the occurence counter of a given Occurence_Pattern in a given Rx_String
        String L_Rx_String = Rx_String;
        String L_Occurence_Pattern = Occurence_Patters;
        Integer L_FromIndex = 0;
        Integer L_Occurence_Counter = 0;
        Boolean L_Continue = true;
        Integer L_FoundIndex = 0;

        while (L_Continue) {
            L_FoundIndex = L_Rx_String.indexOf(L_Occurence_Pattern, L_FromIndex);

            if (!(L_FoundIndex == -1)) {
                L_Occurence_Counter++;
                L_FromIndex = L_FoundIndex + 1;
            } else L_Continue = false;
        }

        return L_Occurence_Counter;
    }
}
