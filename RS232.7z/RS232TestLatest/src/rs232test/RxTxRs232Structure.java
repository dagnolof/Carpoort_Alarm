/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs232test;

//Pricate Variables
public class  RxTxRs232Structure {
    //Private variable
    private boolean L_RxDataFlag = false;
    private boolean L_RxOKFlag = false;
    private boolean L_Enter_Sms_Text_Flag = false;
    private boolean L_Rx_Sms_Flag = false;
    private boolean L_Read_Sms_Flag = false;
    private boolean L_tracer_On_Flag = false;
    // V05 19-Oct-2019
    // Add L_Tx_Sms_Reply_Reveived Flag
    private boolean L_Tx_Sms_Reply_Reveived = false;
    private String L_Rx_String;
    
    private JframeRs232TestMain MainQui;     // Reference to JframeRs232TestMain.java Main Qui
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // Class Constructor
    public RxTxRs232Structure(JframeRs232TestMain L_MainQui) {   // Reference to JframeRs232TestMain.java Main Qui) {
       MainQui = L_MainQui;   // By using MainQui. in this java file, we can use all methodes of the Mainqui
    }

 
    
    /**
     * Copy the received RS232 buffer into the RxStrucure
     * @param RxString 
     */
    public synchronized void CopyRxString(String  RxString){
       this.L_Rx_String = RxString;
 
    }
    
    

    
    
    /**
     * Return the L_Buffer, the receivved RS232 buffer to the caller
     * @return L_Rx_String
     */
    public synchronized String GetRxString() {
        return (this.L_Rx_String);
    }
    
    
    
    /**
     * Change the L_Read_Sms_Flag  in the RxTxRs232Structure.
     * This means that the "+CMGR:" string has been received
     * @param ReadSmsFlag
     */
    public synchronized void ChangeReadSmsFlag (boolean ReadSmsFlag){
        this.L_Read_Sms_Flag = ReadSmsFlag;
    }
    
    
       /**
     * Get the L_Read_Sms_Flag  in the RxTxRs232Structure.
     * @param ReadSmsFlag
     */
    public synchronized boolean GetReadSmsFlag (){
        return this.L_Read_Sms_Flag;
    }
    
    
    /**
     * Change the L_Rx_Sms_Flag  in the RxTxRs232Structure.
     * This means that the "+CMTI:" string has been received
     * @param RxSmsTextFlag 
     */
    public synchronized void ChangeRxSmsFlag (boolean RxSmsFlag){
        this.L_Rx_Sms_Flag = RxSmsFlag;
    }
    
    
    /**
     * Change the L_tracer_On_Flag  in the RxTxRs232Structure.
     * This means that we can write code that only will be triggered when tracing is £ON
     * @param tracerOnFlag 
     */
    public synchronized void ChangeTracerOnFlag (boolean tracerOnFlag){
        this.L_tracer_On_Flag = tracerOnFlag;
    }
    
    
     /**
     * Change the L_tracer_On_Flag  in the RxTxRs232Structure.
     * This means that we can write code that only will be triggered when tracing is £ON
     * @param tracerOnFlag 
     */
    public synchronized Boolean GetTracerOnFlag (){
        return this.L_tracer_On_Flag;
    }
    
   
    /**
     * Get the L_Rx_Sms_Flag in the RxTxRs232Structure.
     * This means that the "+CMTI:" string has been received
     * @param L_Rx_Sms_Flag 
     */
    public synchronized boolean getRxSmsFlag (){
        return this.L_Rx_Sms_Flag;
    }
    
    
    /**
     * Change the L_Enter_Sms_Text_Flag in the RxTxRs232Structure.
     * This means that the ">" character has been received after having send AT+CMGR=+d_gsm_nbr
     * @param EnterSmsTextFlag 
     */
    public synchronized void ChangeEnterSmsTextFlag (boolean EnterSmsTextFlag){
        this.L_Enter_Sms_Text_Flag = EnterSmsTextFlag;
    }
    
    
    /**
     * Get L_Enter_Sms_Text_Flag in the RxTxRs232Structure
     * @param 
     */
    public synchronized boolean GetEnterSmsTextFlag (){
        return this.L_Enter_Sms_Text_Flag;
    }
    
    
    /**
     * Set the L_RxDataFlag in the RxTxRs232Structure.
     * This means dat Data is received on the RS232 Port
     * @param RxDataFlag 
     */
    public synchronized void ChangeRxDataFlag (boolean RxDataFlag){
        this.L_RxDataFlag = RxDataFlag;
    }
    
    
    /**
     * Set the L_TxProgressFlag in the RxTxRs232Structure.
     * This means dat Data is transmitted on the RS232 Port
     * @param TxProgressFlag
     */
/*    public synchronized void SetTxProgressFlag (boolean TxProgressFlag){
        this.L_TxProgressFlag = TxProgressFlag;
    }*/
    
    
    /**
     * Set the L_RxOKFlag in the RxTxRs232Structure.
     * This means that "OK" string  is received on the RS232 Port
     * @param RxOKFlag
     */
    public synchronized void ChangeRxOKFlag (boolean RxOKFlag){
        this.L_RxOKFlag = RxOKFlag;
    }
    
    
    /**
     * Set the L_ModemConnectedFlag in the RxTxRs232Structure.
     * This means that the Gsm Modem is connected to a provider.
     * @param ModemConnectedFlag
     */
    //public synchronized void SetModemConnectedFlag (boolean ModemConnectedFlag){
    //    this.L_ModemConnectedFlag = ModemConnectedFlag;
    //}
    
    
    /**
     * Return L_RxDataFlag to the caller. If set, it means data valid Data is 
     * present in the RxStrucure.
     * @return L_RxDataFlag
     */
    public synchronized boolean GetRxDataFlag(){
        return(this.L_RxDataFlag);
    }
    
    
    /**
     * Return the L_RxOKFlag
     * This means that "OK" string  is received on the RS232 Port
     * @return L_RxOKFlag
     */
    public synchronized boolean GetRxOKFlag() {
        return (this.L_RxOKFlag);
    }
    

    
    /**
     * Change L_Tx_Sms_Reply_Reveived Flag to the caller. If set, Tx SMS reply has been 
     * received   +CMGS
     * @return L_Tx_Sms_Reply_Reveived
     */
    public synchronized void ChangeTxSmsReplyReceivedFlag(boolean ReplyFlag){
        this.L_Tx_Sms_Reply_Reveived = ReplyFlag;
    }
    
    
    
    /**
     * Return the L_Tx_Sms_Reply_Reveived
     * This flag checks if the Tx SMS reply is received
     * @return L_Tx_Sms_Reply_Reveived
     */
    public synchronized boolean GetTxSmsReplyReceivedFlag() {
        return (this.L_Tx_Sms_Reply_Reveived);
    }
}
