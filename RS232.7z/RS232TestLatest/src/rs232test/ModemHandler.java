/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs232test;

import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author fdag0
 */
public class ModemHandler {

    //Private variables of class ModemHandler
    private enum E_State {
        Ms_Start, Ms_Sent_ATE0, Ms_Sent_ATE0_Wait_OK, Ms_Sent_AT, Ms_Sent_AT_Wait_OK, Ms_Sent_AT_CREG, Ms_WAIT_CREG, Ms_Sent_AT_CPIN,
        Ms_WAIT_CPIN, Ms_Wait_SIM_PIN, Ms_Wait_Rx_Data, Ms_Sent_CMGF, Ms_Wait_CMGF_OK, Ms_Sent_CNMI, Ms_Wait_CNMI_OK, Ms_Sent_CGMM, Ms_Wait_CGMM_OK;
    };
    
    private static final Integer T_Wait_AT_CGMM_Reply_Timer_Value = 5;            //5s Timer, 5 x 1000ms
    
    private E_State Z_State, Z_State_Previous;
    private JframeRs232TestMain  MainQui;     //// Reference to JframeRs232TestMain.java Main Qui
    private Timer timer;
    private String RxString;
    private Integer Z_T_Wait_AT_CGMM_Reply_Timer_Counter = 0;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // Constructor of ModemHandler Class
    public ModemHandler(JframeRs232TestMain L_MainQui) {   // L_MainQui is a reference to the calling MainQui
        this.MainQui = L_MainQui;                          // By using MainQui. in this java file, we can use all methodes of the Mainqui
        // Z_State = E_State.Ms_Start;      
        // MainLoopTimer();
     
    }
    
    /**
     * Cancel the Mainlooptimer
     */
    public void ModemHandlerClose(){
       timer.cancel();
    }
    
    /**
     * Start the modemhandler by scheduling the timer that will trigger the Mainloop
     */
    public void ModemHandlerStart() {
        // Initialise Z_State here. If we place this instruction afther the timer.schedule coinstruction.
        // We get NULL pointer execptions error on the use of this variable in the code !!!!!
        this.Z_State = E_State.Ms_Start;
        this.Z_State_Previous = E_State.Ms_Wait_Rx_Data;
        
        // Schedule the Mainloop Timer.
        timer = new Timer();
        timer.schedule(new MainLoop(), 0, 1000);
        
    }
     
    class MainLoop extends TimerTask {
        private int ThreadPriority, ThreadMin, ThreadMax;
        
        public synchronized void run() {
            String L_Time;
            
            if (Z_State.name() == null ? Z_State_Previous.name() != null : !Z_State.name().equals(Z_State_Previous.name())) {
              //MainQui.WriteInLogfile("ModemHandler, Z_State  " + Z_State.name() +   MainQui.Z_Nextline);
              L_Time = genericCode.GetTimeString();
              MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "");
            }
            
            //L_Time = genericCode.GetTimeString();
            ///MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", "test" , "", "");
            Z_State_Previous = Z_State;
            
            /* Handle Lodem State indicator */
            MainQui.HandleModemState();
            
            /* Test code to find problem in V02, String methode Contains NOT working
            if (MainQui.rxStructure.GetRxDataFlag()) {
                    L_Time = genericCode.GetTimeString();
                    MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", "", "", "Mainloop-TimerTask, RxDataFlag is set");
                }else {
                   L_Time = genericCode.GetTimeString();
                   MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", "", "", "Mainloop-TimerTask, RxDataFlag is NOT set");
                }   */
            
            switch (Z_State) {
                case Ms_Start:
                    // Add Log File Entry located in the MainQui Jframe
                    //MainQui.WriteInLogfile("ModemHandler Started " + MainQui.Z_Nextline);
                    L_Time = genericCode.GetTimeString();
                    MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "ModemHandler Started");
                    Z_State = E_State.Ms_Sent_ATE0;

                    break;

                case Ms_Sent_ATE0:
                    MainQui.TransmitModemCommand("ATE0");
                    //MainQui.WriteInLogfile("State Ms_Sent_ATE0 " + MainQui.Z_Nextline);
                    Z_State = E_State.Ms_Sent_ATE0_Wait_OK;
                    
                    break;

                case Ms_Sent_ATE0_Wait_OK:
                    // Check if "OK" string  is received on the RS232 Port
                    if (MainQui.rxStructure.GetRxOKFlag()){
                        // "OK" String is received on the RS232 Port
                        // Clear the RxOKFlag/RxDataFlag
                        MainQui.rxStructure.ChangeRxOKFlag(false);
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        Z_State = E_State.Ms_Sent_AT;
                    }                    
                    break;
     
                case Ms_Sent_AT:
                    MainQui.TransmitModemCommand("AT");
                    Z_State = E_State.Ms_Sent_AT_Wait_OK;
                    break;

                case Ms_Sent_AT_Wait_OK:
                    // Check if "OK" string  is received on the RS232 Port
                    if (MainQui.rxStructure.GetRxOKFlag()) {
                        // "OK" String is received on the RS232 Port
                        // Clear the RxOKFlag/RxDataFlag
                        MainQui.rxStructure.ChangeRxOKFlag(false);
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        Z_State = E_State.Ms_Sent_CMGF;
                    }
                    break;
 
                case Ms_Sent_CMGF:
                    // Set Modem in Text Mode
                    MainQui.TransmitModemCommand("AT+CMGF=1");
                    Z_State = E_State.Ms_Wait_CMGF_OK;
                    break;

                case Ms_Wait_CMGF_OK:
                    // Check if "OK" string  is received on the RS232 Port
                    if (MainQui.rxStructure.GetRxOKFlag()) {
                        // "OK" String is received on the RS232 Port
                        // Clear the RxOKFlag/RxDataFlag
                        MainQui.rxStructure.ChangeRxOKFlag(false);
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        Z_State = E_State.Ms_Sent_CNMI;
                    }
                    break;
                    
                    
                case Ms_Sent_CNMI:
                    // Set Modem SMS autoreply Mode
                    MainQui.TransmitModemCommand("AT+CNMI=2,1,0,0,0");
                    Z_State = E_State.Ms_Wait_CNMI_OK;
                    break;

                    
                case Ms_Wait_CNMI_OK:
                    // Check if "OK" string  is received on the RS232 Port
                    if (MainQui.rxStructure.GetRxOKFlag()) {
                        // "OK" String is received on the RS232 Port
                        // Clear the RxOKFlag/RxDataFlag
                        MainQui.rxStructure.ChangeRxOKFlag(false);
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        //Z_State = E_State.Ms_Sent_AT_CPIN;
                        Z_State = E_State.Ms_Sent_CGMM;
                    }
                    break;                     


                case Ms_Sent_CGMM:
                    // Set Modem SMS autoreply Mode
                    MainQui.TransmitModemCommand("AT+CGMM");
                    Z_State = E_State.Ms_Wait_CGMM_OK;
                    break;

                    
                case Ms_Wait_CGMM_OK:
                    // Check if RxDataflag is set in the RxStructure                      
                    if (MainQui.rxStructure.GetRxDataFlag()) {
                        // Copy the Rx Buffer from the rxStructure in Local Data. This makes the rxStructure Buffer free again.
//                        this.L_Buffer = MainQui.rxStructure.GetRxBuffer();
                        RxString = MainQui.rxStructure.GetRxString();

                        // Clear the RxDataFlag
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        MainQui.rxStructure.ChangeRxOKFlag(false);

                        if (RxString.contains("MULTIBAND  900E  1800")) {
                            //MainQui.WriteInLogfile("Gsm Sim Pin OK " + MainQui.Z_Nextline);
                            L_Time = genericCode.GetTimeString();
                            MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "FASTTRAC Modem Connected ");
                            // Set Modem Type in SustemStructure
                            MainQui.systemStructure.SetModemType("FASTTRAC");

                        } else if (RxString.contains("SIMCOM_SIM5320E")) {
                            L_Time = genericCode.GetTimeString();
                            MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "SIMCOM Modem Connected ");
                            // Set Modem Type in SustemStructure
                            MainQui.systemStructure.SetModemType("SIMCOM");
                        } else {
                            L_Time = genericCode.GetTimeString();
                            MainQui.Write_In_Logfile(L_Time, "Modemhandler.java", "", "", "No Valid Modem Type found");
                        }

                        Z_State = E_State.Ms_Sent_AT_CPIN;
                        
                    } else {
                        //We implement a timer to wait for the Sms reply.
                        //In this way we come out of the situation where the Smartbox is not answering for whatever reason
                        Z_T_Wait_AT_CGMM_Reply_Timer_Counter++;

                        if (Z_T_Wait_AT_CGMM_Reply_Timer_Counter.equals(T_Wait_AT_CGMM_Reply_Timer_Value)) {
                            Z_T_Wait_AT_CGMM_Reply_Timer_Counter = 0;
 //                           Z_T_Wait_Sms_Reply_Retry_Counter++;

/*                            if (Z_T_Wait_Sms_Reply_Retry_Counter >= 2) {
                                //We already retryed on this Smartbox Id
                                //- Set error indication in t_smartboxs
                                Z_T_Wait_Sms_Reply_Retry_Counter = 0;
                                Z_State = E_State.Ms_Set_Smartbox_Err;
                                /*                                Set_Smartbox_Error(d_smartbox_id_Int, "No Reply on Sms");
                                 
                                L_Time = genericCode.GetTimeString();
                                MainQui.WriteInLogfile(L_Time + "SmsHandler Z_State,  " + Z_State.name() + " Sms_Retry_Counter = 2" + MainQui.Z_Nextline);
            
                                Z_State = E_State.Ms_Clear_Modem_Memory;  */
                            L_Time = genericCode.GetTimeString();
                            MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "NO Reply on, AT+CGMM, Retry Command ");
                            
                            Z_State = E_State.Ms_Sent_CGMM;   
                            } 
                        }

                    break;

                    
                case Ms_Sent_AT_CPIN:
                    MainQui.TransmitModemCommand("AT+CPIN?");
                    //MainQui.rxStructure.ChangeRxOKFlag(false);
                    // MainQui.rxStructure.ChangeRxDataFlag(false);
                    Z_State = E_State.Ms_WAIT_CPIN;
                    break;
   
                    
                case Ms_WAIT_CPIN:
                    // Check if RxDataflag is set in the RxStructure
                    L_Time = genericCode.GetTimeString();
//                    MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", "", "", "case Ms_WAIT_CPIN: **********");
                             
                    if (MainQui.rxStructure.GetRxDataFlag()) {
                        // Copy the Rx Buffer from the rxStructure in Local Data. This makes the rxStructure Buffer free again.
//                        this.L_Buffer = MainQui.rxStructure.GetRxBuffer();
                        RxString = MainQui.rxStructure.GetRxString(); 
                   //     System.out.println("Rx_String: " + RxString);
                   //     System.out.println("Rx_String: 123456789012345");

                        
                        // Clear the RxDataFlag
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        MainQui.rxStructure.ChangeRxOKFlag(false);
                        
//                        String RxString = new String(L_Buffer);
                        //if (RxString.contains("+CPIN: READY")) {
 //                       System.out.println("Rx_String: " + "***" +RxString + "***");
                        //RxString = "+CPIN: READY";
 //                       System.out.println("Rx_String: " + "***" +RxString + "***");
                        
 //                       Integer Index = RxString.indexOf("CPIN");            
   //                  System.out.println("Stringlength: " +  RxString.length());
                    
                     
                     
                        
                        if (RxString.contains("+CPIN: READY")) {
                             //MainQui.WriteInLogfile("Gsm Sim Pin OK " + MainQui.Z_Nextline);
                             L_Time = genericCode.GetTimeString();
                             MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "Gsm Sim Pin OK ");
                            // MainQui.rxStructure.SetModemConnectedFlag(true);
                            Z_State = E_State.Ms_Sent_AT_CREG;
                        } else if (RxString.contains("+CPIN: SIM PIN"))  {
                            // Sim Pin is NOT enterred, enter the Sim Pin
                            MainQui.TransmitModemCommand("AT+CPIN=1234");
                            Z_State = E_State.Ms_Wait_SIM_PIN;
                        } else {
                             L_Time = genericCode.GetTimeString();
                             MainQui.Write_In_Logfile(L_Time, "Modemhandler.java", "", "", "Case Ms_Wait_CPIN, No Valid String Received");
                        }
                    }else {
                        L_Time = genericCode.GetTimeString();
                        MainQui.Write_In_Logfile(L_Time, "Modemhandler.java", "", "", "Case Ms_Wait_CPIN, RxDataFlag is NOT set");
                    }
                    break;
                    
                case Ms_Wait_SIM_PIN:
                    // Check if "OK" string  is received on the RS232 Port
                    if (MainQui.rxStructure.GetRxOKFlag()) {
                        // "OK" String is received on the RS232 Port
                        // Clear the RxOKFlag/RxDataFlag
                        MainQui.rxStructure.ChangeRxOKFlag(false);
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        Z_State = E_State.Ms_Wait_Rx_Data;
                    }
                    break;
                    
                case Ms_Sent_AT_CREG:
                    MainQui.TransmitModemCommand("AT+CREG?");
                    //MainQui.rxStructure.ChangeRxOKFlag(false);
                    //MainQui.rxStructure.ChangeRxDataFlag(false);
                    Z_State = E_State.Ms_WAIT_CREG;
                    break;

                case Ms_WAIT_CREG:
                    // Check if RxDataflag is set in the RxStructure
                    if (MainQui.rxStructure.GetRxDataFlag()) {
                        // Copy the Rx Buffer from the rxStructure in Local Data. This makes the rxStructure Buffer free again.
//                        this.L_Buffer = MainQui.rxStructure.GetRxBuffer();
                        RxString = MainQui.rxStructure.GetRxString();

                        // Clear the RxDataFlag
                        MainQui.rxStructure.ChangeRxDataFlag(false);
                        MainQui.rxStructure.ChangeRxOKFlag(false);

//                        System.out.println("Stringlength: " +  RxString.length());
                        
//                        String RxString = new String(L_Buffer);
                        if (RxString.contains("+CREG: 1,1")) {
                            //MainQui.WriteInLogfile("State Ms_WAIT_CREG   Gsm Modem Connected to Provider " + MainQui.Z_Nextline);
                            L_Time = genericCode.GetTimeString();
                            MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "State Ms_WAIT_CREG   Gsm Modem Connected to Provider ");
                            //MainQui.rxStructure.SetModemConnectedFlag(true);
                            MainQui.systemStructure.SetModemConnectedFlag(true);
                            
                            //26-Nov-2018
                            //We set the database parced flag, the database will not be read into the java application anymore.
                            //This makes it way to complicated to mantain the user data, this task can better be handled by the web application.
                            MainQui.systemStructure.SetDatabaseParcedFlag(true);
                            
                            Z_State = E_State.Ms_Wait_Rx_Data;

                        } else {
                            // The modem is not connected to the service provider.
                        }
                    }
                    break;
                    
                case Ms_Wait_Rx_Data:
                    // In this case state, we listen to data from the modem, without PRIOR having send a command.
                    if (MainQui.rxStructure.GetRxDataFlag()) {
                        // Copy the Rx Buffer from the rxStructure in Local Data. This makes the rxStructure Buffer free again.
//                        this.L_Buffer = MainQui.rxStructure.GetRxBuffer();
                        RxString = MainQui.rxStructure.GetRxString();
                       
                        //Clear the RxDataFlag
                        //3-Dec-2018
                        //Here we always clear the RxDataFlags. 
                        //We are only supposed to clear the flags when we received data PRIOR having send a command.
                        //In Smshandler for example we send command AT+CMGD=1,4 to clear the Sim received sms's.
                        //In Smshandler we wait for the OK answer from the modem. We receive OK, we can see this in the 
                        //RX string printed on the screen. However the MainQui.rxStructure.GetRxOKFlag() is FALSE!!!!
                        //Afther a wille we found out the this is because this flag is cleared by the following two statements
                        //in Z_State = E_State.Ms_Wait_Rx_Data; 
                        //We Should only clear the flags, when the received modem reply is a received reply PRIOR to having send a message.
                        //MainQui.rxStructure.ChangeRxDataFlag(false);
                        //MainQui.rxStructure.ChangeRxOKFlag(false);
                    
//                        String RxString = new String(L_Buffer);
                        
                        L_Time = L_Time = genericCode.GetTimeString();
                        //MainQui.WriteInLogfile("ModemHandler Z_State Ms_Wait_rx_data RX: " + (new String(L_SerialReaderBuffer, 0, L_Len)) + MainQui.Z_Nextline);
                        //MainQui.WriteInLogfile(L_Time + "ModemHandler Z_State Ms_Wait_Rx_Data RX:  " + RxString + MainQui.Z_Nextline);
                        MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "ModemHandler Z_State Ms_Wait_Rx_Data RX:  " + RxString);
                        
                        if (RxString.contains("+CREG: 1,1")) {
                            //MainQui.WriteInLogfile("State Ms_Wait_Rx_Data   Gsm Modem Connected to Provider " + MainQui.Z_Nextline);
                            L_Time = L_Time = genericCode.GetTimeString();
                            MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", Z_State.name(), "", "State Ms_Wait_Rx_Data   Gsm Modem Connected to Provider " + RxString);
                            //MainQui.rxStructure.SetModemConnectedFlag(true);
                            MainQui.systemStructure.SetModemConnectedFlag(true);
                            ClearRxFlags();

                        } else if (RxString.contains(">")) {
                            MainQui.rxStructure.ChangeEnterSmsTextFlag(true);
                            ClearRxFlags();
                        } else if (RxString.contains("+CMTI:")) {
                            MainQui.rxStructure.ChangeRxSmsFlag(true);
                            ClearRxFlags();
                        } else if (RxString.contains("+CMGR:")) {
                            MainQui.rxStructure.ChangeReadSmsFlag(true);
                            ClearRxFlags();
                        } else if (RxString.contains("+CMGS:")) {
                            // V05 19-Oct-2019
                            MainQui.rxStructure.ChangeTxSmsReplyReceivedFlag(true);
                            ClearRxFlags();
                        } else {
                            //No entry is matched 
                            L_Time = L_Time = genericCode.GetTimeString();
                            MainQui.rxStructure.ChangeRxDataFlag(false);
                        }
                    }
                    break;
            }
        }
    }
    
    private void ClearRxFlags(){
        //Clear the RxDataFlags 
        MainQui.rxStructure.ChangeRxDataFlag(false);
        MainQui.rxStructure.ChangeRxOKFlag(false);
    }  
}
