/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carpoort_alarm;

import com.pi4j.io.gpio.*;
import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListener;
import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
//import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;
import com.pi4j.wiringpi.Gpio;
//
import com.pi4j.io.gpio.*;
import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;


public class Handle_Inputs {
    
    private Carpoort_Alarm_Main_Gui MainQui;     // Reference to JframeRs232TestMain.java Main Qui
    
    // create gpio controller
    final GpioController gpio = GpioFactory.getInstance();
    // provision gpio pin #02 as an input pin with its internal pull down resistor enabled
    //final GpioPinDigitalInput myButton = gpio.provisionDigitalInputPin(RaspiPin.GPIO_02, PinPullResistance.PULL_DOWN);
    
    // 19-Nov-2019
    // V03
    // We gaan als input GPIO8/Pin3 als input gebruiken. Deze liggen physisch dichter bij elkaar, wat 
    //hardware verbinding gemakkelijker gaat maken.
    final GpioPinDigitalInput I0_GPIO2_Carpoort_Alarm = gpio.provisionDigitalInputPin(RaspiPin.GPIO_02, PinPullResistance.PULL_DOWN);
    // set shutdown state for this input pin
    // myButton.setShutdownOptions(true); 
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    

    // Class Constructor
    Handle_Inputs (Carpoort_Alarm_Main_Gui L_MainQui){
        MainQui = L_MainQui;
    }
    
    
    
    public void Start(){
        String L_Time = genericCode.GetTimeString();
        MainQui.Write_In_Logfile(L_Time, "Handle_Inputs.java", "Handel_Inputs Started", "", "");
        //this.MainQui.Write_In_Screen_Logging("Handel_Inputs Started");

        
        //myButton.setDebounce(1000);
/*        Integer L_Debounce = I0_GPIO8_Carpoort_Alarm.getDebounce(PinState.LOW);
        System.out.println(" Debounce LOW pinstate  :" + L_Debounce);
                
        L_Debounce = I0_GPIO8_Carpoort_Alarm.getDebounce(PinState.HIGH);
        System.out.println(" Debounce HIGH pinstate  :" + L_Debounce);
        
        PinState L_State = I0_GPIO8_Carpoort_Alarm.getState();
        System.out.println(" Pinstate  :" + L_State);   */
        
        if (I0_GPIO2_Carpoort_Alarm.getState() == PinState.HIGH){
           // System.out.println("Pinstate detected HIGH");
           MainQui.input_structure.Update_I0_GPIO2_Carpoort_Alarm(true);
        } else {
            // System.out.println(" Pinstate detected LOW");
            MainQui.input_structure.Update_I0_GPIO2_Carpoort_Alarm(false);
        }

        // create and register gpio pin listener
        I0_GPIO2_Carpoort_Alarm.addListener(new GpioPinListenerDigital() {
            @Override
            public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event) {
                // display pin state on console
                //System.out.println(" --> GPIO PIN STATE CHANGE: " + event.getPin() + " = " + event.getState());
                
                if (event.getState() == PinState.HIGH) MainQui.input_structure.Update_I0_GPIO2_Carpoort_Alarm(true);
                else MainQui.input_structure.Update_I0_GPIO2_Carpoort_Alarm(false);
            }

        }); 
        
    }
    
    
    
  
}
