/*
 * Handle the HTTP GET request
 */
package carpoort_alarm;

// HttpComponents Import
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import java.util.Scanner;
import java.io.*;
import java.util.List;


public class Handle_Http_Get {
    // Private Variables
    private Carpoort_Alarm_Main_Gui MainQui;     // Reference to JframeRs232TestMain.java Main Qui

    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // Class Constructor
    Handle_Http_Get(Carpoort_Alarm_Main_Gui L_MainQui) {
        MainQui = L_MainQui;
    }
    
    
    
    public void Send_Http_Get(){
        //Creating a HttpClient object
        CloseableHttpClient httpclient = HttpClients.createDefault();
    
        //Creating a HttpGet object
        //HttpGet httpget = new HttpGet("https://www.tutorialspoint.com/ ");
        //HttpGet httpget = new HttpGet("http://192.168.0.41/sensormonitor/From_Esp8266.php?UnitId=1&SensorId=1&State=1");
        HttpGet httpget = new HttpGet("http://192.168.0.41/carpoort_alarm/From_Rb-Pi4-Carpoort-Alarm.php?UnitId=1&SensorId=1&State=1");
        
        //Executing the Get request
        try {
            HttpResponse httpresponse = httpclient.execute(httpget);
            String L_Time = genericCode.GetTimeString();
            MainQui.Write_In_Logfile(L_Time, "Handle_Http_Get.java", "", "", "");
            Scanner sc = new Scanner(httpresponse.getEntity().getContent());

            //Printing the status line
            //System.out.println(httpresponse.getStatusLine());
            //this.Write_In_Screen_Logging("", httpresponse.getStatusLine(), true);
            while (sc.hasNext()) {
                //System.out.println(sc.nextLine());
                //MainQui.Write_In_Screen_Logging(sc.nextLine());
                L_Time = genericCode.GetTimeString();
                MainQui.Write_In_Logfile(L_Time, "Handle_Http_Get.java", sc.nextLine(), "", "");
               
            }
            
            sc.close();
            httpclient.close();
            
        } catch (IOException e) {
            // MainQui.Write_In_Screen_Logging("Http Execute IOException occurred");
             String L_Time = genericCode.GetTimeString();
             MainQui.Write_In_Logfile(L_Time, "Handle_Http_Get.java", "", "Erp_01", "Http Execute IOException");
        }finally {

        }
    }
    
    
    
    
    
    
}
