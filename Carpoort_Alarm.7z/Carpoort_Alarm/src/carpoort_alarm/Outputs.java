/*
 * Here all Outputs are defined
*/

package carpoort_alarm;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;
import java.util.Timer;

public class Outputs {

    // Private Variables
    private Carpoort_Alarm_Main_Gui MainQui;     // Reference to JframeRs232TestMain.java Main Qui
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    // create gpio controller
    final GpioController gpio = GpioFactory.getInstance();
        
    // provision gpio pin #01 as an output pin and turn on
    final GpioPinDigitalOutput Q0_GPIO00_Heartbeat = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_00, "Heartbeat", PinState.LOW);
    final GpioPinDigitalOutput Q0_GPIO01_alarm_State = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_01, "Alarm_State", PinState.LOW);
    final GpioPinDigitalOutput Q0_GPIO03_Test_Button = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_03, "Test_Button", PinState.LOW);
    
    // Class Constructor
    Outputs(Carpoort_Alarm_Main_Gui L_MainQui) {
        MainQui = L_MainQui;
    }
    
    
    
    public void Init(){   
      // When proggram is terminated, Q0_Alarm_State led is switched OFF
      this.Q0_GPIO00_Heartbeat.setShutdownOptions(true, PinState.LOW); 
      this.Q0_GPIO01_alarm_State.setShutdownOptions(true, PinState.LOW);
      this.Q0_GPIO03_Test_Button.setShutdownOptions(true, PinState.LOW);
    }   
    
    
}
