/*
 * Input_Structure gaat per input een veld bijhouden, waar Input listner de huidige input state
 * gaat opslaan. Users kunnen uit deze Input_Structure de input waarde uitlezen.
 */
package carpoort_alarm;


public class Input_Structure {
    // Private Variables
    private boolean I0_GPIO2_Carpoort_Alarm = false;

    private Carpoort_Alarm_Main_Gui MainQui;     // Reference to JframeRs232TestMain.java Main Qui

    // Class Constructor
    Input_Structure(Carpoort_Alarm_Main_Gui L_MainQui) {
        MainQui = L_MainQui;
    }
    
    
    /**
     * Update IO_GPIO2_Carpoort_Alarm.
     */
    
    public synchronized void Update_I0_GPIO2_Carpoort_Alarm(Boolean State){
        I0_GPIO2_Carpoort_Alarm = State;
    } 
    
    
    /**
     * Get IO_GPIO2_Carpoort_Alarm.
     */
    
    public synchronized boolean Get_I0_GPIO2_Carpoort_Alarm(){
        return I0_GPIO2_Carpoort_Alarm;
    } 
    
}
