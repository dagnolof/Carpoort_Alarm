/*
 * The application will check Input_Structure I0_GPIO2_Carpoort_Alarm.
 * If Input is found high an sms will be send. 
 */
package carpoort_alarm;

import java.util.Timer;
import java.util.TimerTask;

public class Application {

    // Private Variables
    private Carpoort_Alarm_Main_Gui MainQui;     // Reference to JframeRs232TestMain.java Main Qui
    private enum E_State {Ms_Start, Ms_Check_I0_High, Ms_Check_I0_Low, Ms_Done};
    
    private E_State Z_State, Z_State_Previous;
    private Timer timer;
    
    //Define external Classes
    private GenericCode genericCode = new GenericCode();
    
    
    // Class Constructor
    Application(Carpoort_Alarm_Main_Gui L_MainQui) {
        MainQui = L_MainQui;
    }

    
    
    public void Start() {
        // Initialise Z_State here. If we place this instruction afther the timer.schedule coinstruction.
        // We get NULL pointer execptions error on the use of this variable in the code !!!!!
        this.Z_State = E_State.Ms_Start;
        this.Z_State_Previous = E_State.Ms_Done;

        // Schedule the Mainloop Timer.
        timer = new Timer();
        timer.schedule(new MainLoop(), 0, 250);

    }
    
    
        class MainLoop extends TimerTask {

        public synchronized void run() {
            String L_Time;
            
            if (Z_State.name() == null ? Z_State_Previous.name() != null : !Z_State.name().equals(Z_State_Previous.name())) {
              //MainQui.WriteInLogfile("ModemHandler, Z_State  " + Z_State.name() +   MainQui.Z_Nextline);
              L_Time = genericCode.GetTimeString();
              MainQui.Write_In_Logfile(L_Time, "Application.java", Z_State.name(), "", "");
            }
            
            //L_Time = genericCode.GetTimeString();
            ///MainQui.Write_In_Logfile(L_Time, "ModemHandler.java", "test" , "", "");
            Z_State_Previous = Z_State;
            
            MainQui.outputs.Q0_GPIO00_Heartbeat.toggle();
            
            switch (Z_State) {
                case Ms_Start:
                    Z_State = E_State.Ms_Check_I0_High;
                   
                    break;
                    
                    
                case Ms_Check_I0_High:
                    if (MainQui.input_structure.Get_I0_GPIO2_Carpoort_Alarm()) {
                        // I0_GPIO2_Carpoort_Alarm is set, send Http-Get to send SMS
                        MainQui.handle_htpp_get.Send_Http_Get();
                        
                        // Switch on Alarm Led
                        MainQui.outputs.Q0_GPIO01_alarm_State.high();
                        
                        Z_State = E_State.Ms_Check_I0_Low;
                    }
                    
                    break;        
                
                    
                case Ms_Check_I0_Low:
                    if (!MainQui.input_structure.Get_I0_GPIO2_Carpoort_Alarm()) {
                        // I0_GPIO2_Carpoort_Alarm is reset, Got to Ms_Check_IO_High
                        
                        // Clear Alarm Led
                        MainQui.outputs.Q0_GPIO01_alarm_State.low();
                        Z_State = E_State.Ms_Check_I0_High;
                    }
                    
                    break;          
            }

        }
    }
}
